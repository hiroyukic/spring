﻿'----------------------------------------------------
'wtjの構文解析クラス
' 解析対象のファイルパスを受けて、構文解析を行い、結果を出力
'----------------------------------------------------

Imports System.Text.RegularExpressions


Public Class SyntacticAnalysis

    Const DBGFLG As Boolean = 1


    Const WTJ_FILE As String = "D:\Work\test.csv"


    Private FilePath As String

    Private intTotalLineCount As UInteger

    Private dict As CommonDirectory

    ' Directory用・関数キーワード
    Const FUNCT As String = "FUNCT"
    Const OPE As String = "OPERATOR"
    Const VIEW_FILTER_CLASS As String = "VIEW_FILTER_CLASS"




    'ファイルの生成日時
    Private FILE_CREAT_TIME As String
    'ファイルの格納ディレクトリ  ※直近親ディレクトリ
    Private FILE_PARENT_DIR As String

    Private FILE_NAME_BODY As String


    '出力属性情報クラス
    Private RECORD As StructRecord


    'ビューフィルタ構造体 　※'[VFilter] [CFilter] [CFValue]
    Private Structure STRUCT_VIEW_FILTER
        Public AtrributeList As String()          ' 属性のリスト配列

        '[VFilter] ビューフィルタ定義
        Public VF1Kind As Integer           'ビューフィルタ区分
        Public VF1KindName As String        'ビューフィルタ区分名称
        Public VF1FilterId As Integer             '
        Public VF1FilterName As String            '
        '[CFilter] 移送先・属性ＩＤ
        Public CF2FiltererOutViewId As Integer    '
        Public CF2FilterOutColId As Integer       '
        '[CFValue]
        Public CFV3ValueViewID As Integer         ' 移送元・ビューID
        Public CFV3ValueValue As String           ' 移送元・移送値
        Public CFV3ValueSFType                    ' 関数タイプ
        Public CFV3ValueRealValueType             ' 実値型
        Public CFV3ValuelikColID                  ' 移送元・カラムID
        Public CFV3ValueID                        ' a
        Public CFV3ValueIsRoot                    ' ルートフラグ
        Public CFV3ValueChildIDs As String        ' パラメータ
        '二項比較子
        Public CFV3ValueValueType As String       'ValueType
        Public CFV3ValueSetValueType As String    'SetValueType
        Public CFV3ValueObjType As String         'ObjType
        '
        Public CFV3ValueName As String            '
    End Structure

    Private recordViewFilter As STRUCT_VIEW_FILTER

    ' タグ・キーワード  Enum
    Private Enum Status
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iSquareBracket
        iNone
    End Enum

    'タグ・キーワード  ストリングパターン
    Private regPatternView As String = "^\[View\]"
    Private regPatternColumn As String = "^\[Column\]"
    Private regPatternVFilter As String = "^\[VFilter\]"
    Private regPatternCFilter As String = "^\[CFilter\]"
    Private regPatternCFValue As String = "^\[CFValue\]"
    Private regPatternSelectCondition As String = "^\[SelectCondition\]"
    Private regPatternDViewSelectCondition As String = "^\[DViewSelectCondition\]"
    Private regPatternDeleteSelectContdition As String = "^\[DeleteSelectContdition\]"
    Private regPatternRepository As String = "^\[Repository\]"
    Private regPatternProcess As String = "^\[Process\]"
    Private regPatternViewInfo As String = "^\[ViewInfo\]"
    Private regPatternLookupViewInfo As String = "^\[LookupViewInfo\]"
    Private regPatternSquareBracket As String = "^\["
    '----------------------------------------------------------------------------------
    Private rxView = New Regex(regPatternView, RegexOptions.Compiled)
    Private rxColumn = New Regex(regPatternColumn, RegexOptions.Compiled)
    Private rxVFilter = New Regex(regPatternVFilter, RegexOptions.Compiled)
    Private rxCFilter = New Regex(regPatternCFilter, RegexOptions.Compiled)
    Private rxCFValue = New Regex(regPatternCFValue, RegexOptions.Compiled)
    Private rxSelectCondition = New Regex(regPatternSelectCondition, RegexOptions.Compiled)
    Private rxDViewSelectCondition = New Regex(regPatternDViewSelectCondition, RegexOptions.Compiled)
    Private rxDeleteSelectContdition = New Regex(regPatternDeleteSelectContdition, RegexOptions.Compiled)
    Private rxRepository = New Regex(regPatternRepository, RegexOptions.Compiled)
    Private rxProcess = New Regex(regPatternProcess, RegexOptions.Compiled)
    Private rxViewInfo = New Regex(regPatternViewInfo, RegexOptions.Compiled)
    Private rxLookupViewInfo = New Regex(regPatternLookupViewInfo, RegexOptions.Compiled)
    Private rxSquareBracket = New Regex(regPatternSquareBracket, RegexOptions.Compiled)

    'Dictionaly 分別キーワード
    Private Const VIEW As String = "VIEW"
    Private Const COLUMN As String = "COLUMN"
    Private Const COLUMN_LENGTH As String = "COLUMN_LENGTH"

    '[View」テーブル定義名称を格納する。※IDをインデックスとしたストリング名称を格納する。
    'Private hashViewTable = New Hashtable()
    Private hashViewTable

    '[Column」テーブル属性名称を格納する。※IDをインデックスとしたテーブルの属性名称を格納する。
    'Private hashColumn
    'Private hashColumnLength


    'TagBlock
    Private intTAG_BLOCK_ID As String
    'Setter/Getter
    Private Function GetTAG_BLOCK_ID() As String
        Return intTAG_BLOCK_ID
    End Function
    Private Function SetTAG_BLOCK_ID(ByVal val As String)
        intTAG_BLOCK_ID = val
    End Function

    'ViewID
    Private intVIEW_ID As String
    'Setter/Getter
    Private Function GetVIEW_ID() As String
        Return intVIEW_ID
    End Function
    Private Function SetVIEW_ID(ByVal val As String)
        intVIEW_ID = val
    End Function

    ''' -----------------------------------------------------------------------------------
    ''' コンストラクタ
    ''' -----------------------------------------------------------------------------------
    Public Sub New()
    End Sub

    Public Sub New(ByVal strPath As String)
        If strPath Is Nothing Then
            Throw New ArgumentNullException(NameOf(strPath))
        End If
    End Sub

    ''' -----------------------------------------------------------------------------------
    ''' 初期化
    ''' -----------------------------------------------------------------------------------
    Public Sub Initialize(ByVal strPath As String)
    End Sub


    '■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    ' wtj→text へ構文変換
    ' ファイル名称を引き受け、読み込みながら構文解析を行う。
    'Public Sub Parce(ByVal strPath As String)
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="strPath"></param>
    Public Sub Conversion(ByVal strPath As String)

        'ハッシュテーブル初期化　※wtj毎に初期化
        hashViewTable = New Hashtable()

        'hashColumn = New Hashtable()

        'hashColumnLength = New Hashtable()

        'hashViewTable.GetHashCode()


        'ディクショナリー初期化
        dict = New CommonDirectory


        '1.ファイル存在チェック
        If IO.File.Exists(strPath) = False Then
            Exit Sub
        End If

        'ファイルのタイムスタンプ
        Me.FILE_CREAT_TIME = System.IO.File.GetCreationTime(strPath)
        'ファイル格納ディレクトリ  ※直近親ディレクトリ →業務名
        'Me.FILE_PARENT_DIR = System.IO.Directory.GetCurrentDirectory(strPath)
        'Me.FILE_NAME_BODY = System.IO.Directory.GetCurrentDirectory(strPath)
        'Me.FILE_NAME_BODY = System.IO.Path.GetFileName(strPath)


        '2.ファイル読込み
        Dim cReader As IO.StreamReader
        '読込ストリーマ
        cReader = New IO.StreamReader(strPath, System.Text.Encoding.Default)

        '書込ストリーマ
        'Using cWriter = New IO.StreamWriter(New IO.FileStream("D:\work\test.csv", IO.FileMode.Create))



        Using cWriter = New System.IO.StreamWriter(WTJ_FILE, False, System.Text.Encoding.GetEncoding("shift_jis"))

            'タイトル
            cWriter.WriteLine(StructRecord.COL_TITLE)

            ' ---------------------------------
            ' 出力レコードクラスのインスタンス化
            ' ---------------------------------
            Me.RECORD = New StructRecord

            Try
                '親ディレクトリ取得　→「格納フォルダ」
                Dim dirInfo As System.IO.DirectoryInfo = System.IO.Directory.GetParent(strPath)
                Me.RECORD.C2_DIR = dirInfo.Name()

                'ファイル名称　→「WTJファイル名」
                Me.RECORD.C3_WTJ_FILE_NAME = System.IO.Path.GetFileName(strPath)


                'ファイル・「更新」タイムスタンプ
                'Dim timeStamp As DateTime = System.IO.File.GetCreationTime(strPath)
                Dim timeStamp As DateTime = System.IO.File.GetLastWriteTime(strPath).ToString
                'Dim sss As String = String.Format("{0:yyyyMMddHH}0000", timeStamp)
                Me.RECORD.C1_MODIFY_TIME = String.Format("{0:yyyyMMddHH}0000", timeStamp)

            Catch ex As Exception
                Me.CONSOLEWRITE("Sub Conversio : ", ex.ToString)
            End Try

            'ファイル読込み
            Dim intBlockID As UInteger = 0   'タグＩＤ保持用
            Dim intBlockLineCount As UInteger = 0   'タグブロック内行カウンター

            Dim strOutLine As String
            Dim strLine As String
            Dim intStatus As String

            Dim intRowCount As Integer = 0

            While (cReader.Peek() >= 0)
                intRowCount += 1

                Me.RECORD.C0_SEQ_NUM += 1


                '１行読込み
                strLine = cReader.ReadLine

                'タグキーワードに紐ずくＩＤを取得する。
                intStatus = getStatus(strLine)
                'Console.WriteLine("0>intStatus " & intStatus & ":" & strLine)



                '読込行にタグが検出された場合ブロック内カウンターを初期化する。
                'If (intBlockLineCount > 0 & intStatus <> Status.iNone) Then
                If (intStatus <> Status.iNone) Then
                    '新しいタグ検知
                    intBlockLineCount = 0
                    intBlockID = intStatus
                    Me.CONSOLEWRITE("L280 新しいBlockID ", intBlockID)
                Else
                    intBlockLineCount += 1
                End If

                ' -------------------------------------
                '構文解析　※各タグ毎の構文解析を行う
                ' -------------------------------------
                strOutLine = Parcer(intBlockID, intBlockLineCount, strLine)

                'ファイル出力
                If (strOutLine <> Nothing) Then
                    'Me.CONSOLEWRITE("L275 IN ", strLine)
                    'Me.CONSOLEWRITE("L276 OUT", strOutLine)

                    cWriter.WriteLine(strOutLine)
                End If


            End While
            cReader.Close()

            cWriter.Flush()
        End Using
        'cWriter.FlushAsync()
        'cWriter.Close()

        'Console.WriteLine("  >" & hashColumn.ToString())
        ' キーの列挙
        'For Each key As String In hashColumn.Keys
        '    Dim val As String = hashColumn(key)
        '    Me.CONSOLEWRITE(key, val)
        'Next

        '*************************
        dict.print()


        'Dim fileReader As System.IO.StreamReader
        'fileReader =
        'My.Computer.FileSystem.OpenTextFileReader(strPath)
        'Dim stringReader As String
        'stringReader = fileReader.ReadLine()
        MsgBox("The first line of the file is ")


        '2.タグチェック　[View],[Column],[VFilter],[CFilter]...


        '3.タグブロック内処理
        '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる

    End Sub


    '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる

    '構文解析　※各タグ毎の構文解析を行う
    'strOutLine = parcer(intBlockID, intBlockLineCount, strLine)


#Region "タグキーワードのパターンマッチ"
    '■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function Parcer(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As String

        If (strLine = Nothing) Then
            Return Nothing
        End If

        'Select Case intBlockID
        '現在のタグのブロックＩＤによって、構文の処理を変える
        Dim retLine = ""
        Select Case GetTAG_BLOCK_ID()
            Case Status.iView
                'CONSOLEWRITE("Parcer", "■iView")
                Parcer_View(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iColumn
                'CONSOLEWRITE("Parcer", "■iColumn")
                '[View]ブロックの次には必ず[Column]ブロックが定義される。
                Parcer_Colum(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iVFilter
                '[VFilter]ブロック  ビューフィルタ定義
                'CONSOLEWRITE("Parcer", "■iVFilter")
                Parcer_VFilter(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iViewInfo
                '[ViewInfo]ブロック  ビューフィルタ定義
                'CONSOLEWRITE("Parcer", "■ViewInfo")
                If Parcer_ViewInfo(intBlockID, intBlockLineCount, strLine) Then
                    If DBGFLG Then
                        Return Me.RECORD.getLine(Status.iViewInfo) & ",[ViewInfo]"
                    Else
                        Return Me.RECORD.getLine(Status.iViewInfo)
                    End If
                Else
                    Return Nothing
                End If



            Case Status.iSelectCondition, Status.iDViewSelectCondition, Status.iDeleteSelectContdition
                ' , Status.iViewInfo


                '[SelectCondition]ブロック  抽出条件
                'CONSOLEWRITE("Parcer", "■SelectionCondition>>>>>>>>>>>>>>>>>>>>>>>>>" & GetTAG_BLOCK_ID())

                If Parcer_SelectCondition(intBlockID, intBlockLineCount, strLine) Then

                    If DBGFLG Then
                        Return Me.RECORD.getLine(Status.iSelectCondition) & ",[SelectCondition]"
                    Else
                        Return Me.RECORD.getLine(Status.iSelectCondition)
                    End If

                    'Return Me.RECORD.getLine(Status.iSelectCondition)
                Else
                    Return Nothing
                End If




            ' ================ CFilter ================
            Case Status.iCFilter
                'ONSOLEWRITE("Parcer", "■CFilter")
                Parcer_CFilter(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iCFValue
                'ONSOLEWRITE("Parcer", "■CFValue")
                If Parcer_CFValue(intBlockID, intBlockLineCount, strLine) Then
                    'Return Me.RECORD.getLine(Status.iCFValue)

                    If DBGFLG Then
                        Return Me.RECORD.getLine(Status.iCFValue) & ",[CFValue]"
                    Else
                        Return Me.RECORD.getLine(Status.iCFValue)
                    End If
                Else
                    Return Nothing
                End If


            Case Status.iRepository
                Return Nothing
            Case Status.iProcess
                Return Nothing
            Case Status.iLookupViewInfo
                Return Nothing
                'Case Status.iNone
                '    Return Nothing

        End Select


        'Return Status.iNone


        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        '        If rxView.IsMatch(strLine) Then
        '        Console.WriteLine("0■    " & strLine)
        '        Return Status.iView
        '        ElseIf rxColumn.IsMatch(strLine) Then
        '        Return Status.iLookupViewInfo
        '        Else
        '        Return Status.iNone
        '        End If

    End Function
#End Region


#Region "タグキーワードのパターンマッチ"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function getStatus(ByVal strLine As String) As UInteger

        If (strLine = Nothing) Then
            Return Status.iNone
        End If

        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        If rxView.IsMatch(strLine) Then
            SetTAG_BLOCK_ID(Status.iView)
            Return Status.iView
        ElseIf rxColumn.IsMatch(strLine) Then
            SetTAG_BLOCK_ID(Status.iColumn)
            Return Status.iColumn
        ElseIf rxVFilter.IsMatch(strLine) Then
            SetTAG_BLOCK_ID(Status.iVFilter)
            Return Status.iVFilter
        ElseIf rxCFilter.IsMatch(strLine) Then
            'Console.WriteLine("3■    " & strLine)
            SetTAG_BLOCK_ID(Status.iCFilter)
            Return Status.iCFilter
        ElseIf rxCFValue.IsMatch(strLine) Then
            'Console.WriteLine("4■    " & strLine)
            SetTAG_BLOCK_ID(Status.iCFValue)
            Return Status.iCFValue
        ElseIf rxSelectCondition.IsMatch(strLine) Then
            'Console.WriteLine("5■    " & strLine)
            SetTAG_BLOCK_ID(Status.iSelectCondition)
            Return Status.iSelectCondition
        ElseIf rxDViewSelectCondition.IsMatch(strLine) Then
            'Console.WriteLine("6■    " & strLine)
            SetTAG_BLOCK_ID(Status.iDViewSelectCondition)
            Return Status.iDViewSelectCondition
        ElseIf rxDeleteSelectContdition.IsMatch(strLine) Then
            'Console.WriteLine("7■    " & strLine)
            SetTAG_BLOCK_ID(Status.iDeleteSelectContdition)
            Return Status.iDeleteSelectContdition
        ElseIf rxRepository.IsMatch(strLine) Then
            'Console.WriteLine("8■    " & strLine)
            SetTAG_BLOCK_ID(Status.iRepository)
            Return Status.iRepository
        ElseIf rxProcess.IsMatch(strLine) Then
            'Console.WriteLine("9■    " & strLine)
            SetTAG_BLOCK_ID(Status.iProcess)
            Return Status.iProcess
        ElseIf rxViewInfo.IsMatch(strLine) Then
            'Console.WriteLine("10■    " & strLine)
            SetTAG_BLOCK_ID(Status.iViewInfo)
            Return Status.iViewInfo
        ElseIf rxLookupViewInfo.IsMatch(strLine) Then
            'Console.WriteLine("12■    " & strLine)
            SetTAG_BLOCK_ID(Status.iLookupViewInfo)
            Return Status.iLookupViewInfo
        ElseIf rxSquareBracket.IsMatch(strLine) Then
            'Console.WriteLine("13■    " & strLine)
            SetTAG_BLOCK_ID(Status.iSquareBracket)
            Return Status.iSquareBracket
        Else
            Return Status.iNone
        End If


    End Function
#End Region


#Region "Percer : [View]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  ①　[View]タグブロックのパース 
    '''  ※View ブロックからＩ／Ｏテーブル名称を取得し、Viewハッシュにストアする。
    '''  ※タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub Parcer_View(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If

        Dim columnsList As String()

        Try
            If intBlockLineCount = 2 Then
                ' カンマ区切りで分割して配列に格納する
                columnsList = Split(strLine, Chr(9), , CompareMethod.Text)
                'ViewハッシュにテーブルＩＤとテーブル名称を登録
                If columnsList.Length > 7 Then
                    Dim viewID As String = columnsList(7)    'View ID
                    Dim viewName As String = columnsList(8)  'View 名称
                    SetVIEW_ID(viewID)

                    'View ID をハッシュ登録
                    'hashViewTable.Add(GetVIEW_ID(), viewName)

                    ' ★★★★★★★★★★★★★★★★ 
                    dict.SetAttr(VIEW, GetVIEW_ID(), viewName)

                End If
            End If
        Catch ex As System.AggregateException
            MessageBox.Show(ex.StackTrace, "xxxxxxxxxxxx")
        End Try
    End Sub
#End Region


#Region "Percer : [View]-[Colum]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  ②　[Colum]タグブロックのパース 
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub Parcer_Colum(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If

        Dim columnsList As String()
        'If intBlockLineCount = 3 Then
        If intBlockLineCount >= 2 Then
            ' カンマ区切りで分割して配列に格納する
            columnsList = Split(strLine, Chr(9), , CompareMethod.Text)

            'ViewハッシュにテーブルＩＤとテーブル名称を登録
            If columnsList.Length > 6 Then
                Dim columnName As String = columnsList(5)   '属性名称
                Dim columnLength As String = columnsList(6) '属性長
                Dim columnID As String = columnsList(10)    '属性ID

                Dim key As String = GetVIEW_ID() & "_" & columnID

                '属性名称、属性長をハッシュにストア
                'hashColumn.Add(key, columnName)
                'hashColumnLength.Add(key, columnLength)


                ' ★★★★★★★★★★★★★★★★ 
                Me.dict.SetAttr(COLUMN, GetVIEW_ID, columnID, columnName)
                Me.dict.SetAttr(COLUMN_LENGTH, GetVIEW_ID, columnID, columnLength)


            End If
        End If
    End Sub
#End Region


#Region "Percer : [VFilter]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  [View]タグブロックのパース 
    '''  
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub Parcer_VFilter(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If

        Try

            Dim columns As String() = Split(strLine, Chr(9), , CompareMethod.Text)

            'If intBlockLineCount = 3 Then

            If intBlockLineCount = 1 Then
                ' [1]タイトル行
                ' カンマ区切りで分割して配列に格納する
                columns = Split(strLine, Chr(9), , CompareMethod.Text)

                ''ViewハッシュにテーブルＩＤとテーブル名称を登録
                'If columnsList.Length > 6 Then
                '    Dim columnName As String = columnsList(5)   '属性名称
                'End If

                'ビューフィルタ構造体 初期化
                recordViewFilter = New STRUCT_VIEW_FILTER With {
                        .AtrributeList = columns
                    }
                'ElseIf intBlockLineCount = 3 Then
                'ElseIf intBlockLineCount = 2 Then
            ElseIf intBlockLineCount >= 2 Then
                ' [2]フィルター定義｛フィルター種別、フィルター名称｝
                ' カンマ区切りで分割して配列に格納する
                columns = Split(strLine, Chr(9), , CompareMethod.Text)

                '配列中キーワードにマッチしたインデックス
                Dim indexKind As Integer = getKeysindex(recordViewFilter.AtrributeList, "Kind")
                Dim indexId As Integer = getKeysindex(recordViewFilter.AtrributeList, "ID")
                Dim indexrName As String = getKeysindex(recordViewFilter.AtrributeList, "Name")

                'レコードオブジェクトに設定
                Me.recordViewFilter.VF1Kind = columns(indexKind)
                Me.recordViewFilter.VF1FilterId = columns(indexId)
                Me.recordViewFilter.VF1FilterName = columns(indexrName)




                Me.RECORD.C4_VIEW_FILTER_KBN = columns(indexKind).Trim()
                Me.RECORD.C5_VIEW_FILTER_KBN_NAME = Me.dict.GetAttr(VIEW_FILTER_CLASS, Me.RECORD.C4_VIEW_FILTER_KBN)





                'ヴューフィルタの名称は、StructRecore中にて設定するためここでは不定
                'Me.RECORD.VFilterKindName = columns(indexKind)
                Me.RECORD.C6_VIEW_FILTER_NAME = columns(indexrName)


            End If


            'getKeysindex


            ''ビューフィルタ構造体 初期化
            'recordViewFilter = New STRUCT_VIEW_FILTER With {
            '    .AtrributeList = columns,
            '    .VF1Kind = 2,          'ビューフィルタ区分
            '    .VF1KindName = 2,      'ビューフィルタ区分名称
            '    .VF1FilterId = 2,
            '    .VF1FilterName = "NNNNNNN"
            '}


        Catch ex As System.Exception
            MessageBox.Show(ex.StackTrace, "xxxxxxxxxxxx")
        End Try
    End Sub
#End Region


#Region "Percer : [VFilter]-[VewInfo]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  [VewInfo]タグブロックのパース 
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Function Parcer_ViewInfo(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1

        Dim arryColumns As String()
        '■■■■■■■■■■■■■■■■■■■■■■■■
        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        If intBlockLineCount > 1 Then
            ' カンマ区切りで分割して配列に格納する
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)

            Dim strViewKind = arryColumns(0).Trim   '0:入力ファイル、1:分割ファイル
            Dim strViewId = arryColumns(1).Trim     '前処理[0]、後処理[1]

            Dim strInputViewId As String = ""       '入力ビューID
            Dim strInputView As String = ""         '入力ビュー名称
            Dim strOutputViewId As String = ""      '出力ビューID
            Dim strOutputView As String = ""        '出力ビュー名称
            '■■■■■■■■■■■■■■■■■■■■■■■■
            ' todo
            If (strViewKind.StartsWith("0")) Then
                '①入力情報
                strInputViewId = strViewId
                'strInputView = CStr(hashViewTable(strViewId))
                strInputView = CStr(dict.GetAttr(VIEW, strViewId))

                strOutputViewId = "-"
                strOutputView = "-"

                '移送元ビューID/名称
                Me.RECORD.C12_ORG_VIEW_ID = strViewId
                Me.RECORD.C13_ORG_VIEW_NAME = strInputView
                '移送先ビューID/名称
                Me.RECORD.C7_DIST_VIEW_ID = "-"
                Me.RECORD.C8_DIST_VIEW_NAME = "-"
                Return True
            Else
                '②出力情報
                strOutputViewId = strViewId
                'strOutputView = CStr(hashViewTable(strViewId))

                ' ★★★★★★★★★★★★★★★★ 
                'strOutputView = CStr(dict.GetAttr(VIEW, strViewId))

                '移送先ビューID/名称
                Me.RECORD.C7_DIST_VIEW_ID = strViewId
                'Me.RECORD.DistView = CStr(hashViewTable(strViewId))

                ' ★★★★★★★★★★★★★★★★ 
                Me.RECORD.C8_DIST_VIEW_NAME = CStr(dict.GetAttr(VIEW, strViewId))



                'LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
                'Me.RECORD.VFilterKind = CStr(strViewId))


                Return True
            End If
        End If
        Return False
    End Function
#End Region

#Region "Percer : [VFilter]-[SelectCondition]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' <summary>
    '''  [SelectCondition]タグブロックのパース 
    '''   ブロックから抽出条件を取得する。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    Private Function Parcer_SelectCondition(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1
        Dim arryColumns As String()

        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        'If intBlockLineCount >= 2 Then
        If intBlockLineCount >= 3 Then
            ' カンマ区切りで分割して配列に格納する
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)

            '移送元　属性情報の取得
            '参照ビューＩＤ
            Dim strSelectConditionViewID = arryColumns(0).Trim
            '設定値
            Dim strSelectConditionValue = arryColumns(2).Trim
            '演算子
            Dim strSelectConditionOperator = arryColumns(3).Trim
            '参照テーブルのカラムＩＤ
            Dim strSelectConditionColumnID = arryColumns(10).Trim

            '属性名称を取得
            Dim key As String = strSelectConditionViewID & "_" & strSelectConditionColumnID
            Dim val As String
            Try
                ' ★★★★★★★★★★★★★★★★ 
                val = CStr(dict.GetAttr(COLUMN, strSelectConditionViewID, strSelectConditionColumnID))

                Me.RECORD.C16_ORG_COL_NAME = val

                Me.RECORD.C23_SELECT_TERM = val
                Me.RECORD.C22_SELECT_OPERATER = CStr(dict.GetAttr(OPE, strSelectConditionOperator))
                Me.RECORD.C21_SELECT_CONDITION = strSelectConditionValue

                If val = Nothing Then
                    Return False
                End If
            Catch ex As Exception

                Return False
            End Try

            'Me.RECORD.SelectConditionOpe = strSelectConditionOperator

            Return True

        End If
        Return False
    End Function
#End Region


#Region "Percer : [CFilter]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' <summary>
    '''  [CFilter]タグブロックのパース 
    '''   移送先・属性情報
    '''  </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    Private Function Parcer_CFilter(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1

        Dim arryColumns As String()
        '■■■■■■■■■■■■■■■■■■■■■■■■
        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        If intBlockLineCount >= 2 Then
            ' カンマ区割
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)


            '移送先ビューＩＤ
            Dim strDistViewId = arryColumns(0).Trim
            '属性項目
            Dim strDistColId = arryColumns(1).Trim

            '属性名称を取得
            Dim val As String
            Try
                Dim key As String = strDistViewId & "_" & strDistColId
                'val = hashColumn(key)

                ' ★★★★★★★★★★★★★★★★ 
                'val = CStr(dict.GetAttr(strSelectConditionViewID, strSelectConditionColumnID))
                val = CStr(dict.GetAttr(COLUMN, strDistViewId, strDistColId))

                If val = Nothing Then
                    Return False
                End If
            Catch ex As Exception
                'foo = "-"
                Return False
            End Try


            Me.RECORD.C12_ORG_VIEW_ID = strDistViewId
            'Me.RECORD.DistView = hashViewTable(strDistViewId)
            Me.RECORD.C8_DIST_VIEW_NAME = CStr(dict.GetAttr(VIEW, strDistViewId))


            ' ★★★★★★★★★★★★★★★★ 
            'val = CStr(dict.GetAttr())

            Me.RECORD.C9_DIST_COL_ID = strDistColId
            'Me.RECORD.DistColName = Me.hashColumn(strDistColId)
            Me.RECORD.C11_DIST_COL_NAME = CStr(dict.GetAttr(COLUMN, strDistViewId, strDistColId))
            Me.RECORD.C10_DIST_COL_LEN = CStr(dict.GetAttr(COLUMN_LENGTH, strDistViewId, strDistColId))


            Return True

        End If
        Return False
    End Function
#End Region

#Region "Percer : [CFilter]-[CFValue]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' <summary>
    '''  [CFValue]タグブロックのパース 
    '''   移送先・属性情報
    '''  </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    Private Function Parcer_CFValue(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1

        Dim arryColumns As String()
        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        If intBlockLineCount >= 2 Then
            ' カンマ区割
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)

            ' 移送元・ビューID
            Dim c0_ViewID = arryColumns(0).Trim()
            '' 移送元・型
            Dim c1_ValueType = arryColumns(1).Trim()
            ' 移送元・移送値
            Dim c2_Value = arryColumns(2).Trim()
            Dim c3_SetValueType = arryColumns(3).Trim()
            ' 関数タイプ
            Dim c4_SFType = arryColumns(4).Trim()


            ' 実値型
            Dim c5_RealValueType = arryColumns(5).Trim()
            Dim c6_ObjType = arryColumns(6).Trim()
            Dim c7_Name = arryColumns(7).Trim()
            Dim c8_LookupInfoID = arryColumns(8).Trim()
            ' 移送元・カラムID
            Dim c9_LinkColID = arryColumns(9).Trim()
            ' ルートフラグ （直接移送）
            Dim c10_IsRoot = arryColumns(10).Trim()
            Dim c11_ID = arryColumns(11).Trim()
            Dim c12_Comment = arryColumns(12).Trim()
            ' パラメータ （直接移送）
            Dim c13_ChildIDs = arryColumns(13).Trim()


            '移送元・属性情報
            Try
                Dim functionNum As Integer
                Try
                    functionNum = Integer.Parse(c4_SFType)
                Catch ex As Exception
                    functionNum = 0
                End Try

                Me.RECORD.C19_FUNCTION_TYPE = CStr(dict.GetAttr(FUNCT, c4_SFType))

                '移送元・ビューID
                Me.RECORD.C12_ORG_VIEW_ID = CStr(c0_ViewID)
                Me.RECORD.C18_TRANCE_VALUE = CStr(c2_Value)
                '移送元・ビューテーブル名称
                Me.RECORD.C13_ORG_VIEW_NAME = CStr(dict.GetAttr(VIEW, c0_ViewID))
                '移送元・カラム名称
                Me.RECORD.C14_ORG_COL_ID = CStr(c9_LinkColID)
                '移送元・カラム長
                Me.RECORD.C15_ORG_COL_LEN = dict.GetAttr(COLUMN_LENGTH, c0_ViewID, c9_LinkColID)

                '移送元・カラム名称
                Me.RECORD.C16_ORG_COL_NAME = CStr(dict.GetAttr(COLUMN, c0_ViewID, c9_LinkColID))
                Me.RECORD.C17_TRANCE_TYPE = CStr(c5_RealValueType)
                Me.RECORD.C19_FUNCTION_TYPE = CStr(c4_SFType)

                '直送フラグ
                ' IsRoot=1 かつ ChildsIds=0 の場合、"直接移送" とみなす
                If c10_IsRoot = "1" And c13_ChildIDs = "0" Then
                    Me.RECORD.C20_DIRECT_FLG = "1"
                Else
                    Me.RECORD.C20_DIRECT_FLG = ""
                End If

                Dim functionName As String
                Dim operatorName As String
                Dim value As String
                If c0_ViewID = "0" And c9_LinkColID = "0" Then
                    '①Waha関数設定
                    If functionNum > 0 Then
                        Me.RECORD.C14_ORG_COL_ID = "0"
                        Me.RECORD.C15_ORG_COL_LEN = "0"
                        functionName = dict.GetAttr(FUNCT, c4_SFType)
                        If functionName.Length > 0 Then
                            Me.RECORD.C16_ORG_COL_NAME = "■Function[" & functionName & "]"
                        Else
                            '関数がDictionaryに登録されていない場合 , 関数IDを出力
                            Me.RECORD.C16_ORG_COL_NAME = "■Function[" & functionNum & "]"
                        End If
                    ElseIf c5_RealValueType <> "0" Then
                        '②移送元Value : カンマ、ダブルコーテーション置換
                        value = c2_Value.Replace(",", "、")
                        'orgValue = orgValue.Replace("\"", "”")
                        Me.RECORD.C16_ORG_COL_NAME = "□Value[" & value & "]"
                    ElseIf c1_ValueType = "6" And c3_SetValueType = "101" And c6_ObjType = "5" Then
                        'TODO
                        Me.RECORD.C16_ORG_COL_NAME = ""
                        operatorName = dict.GetAttr(OPE, c0_ViewID)
                        Me.RECORD.C16_ORG_COL_NAME = "□Ope[" & operatorName & "]"

                    ElseIf c1_ValueType = "1" And c3_SetValueType = "8" And c6_ObjType = "3" Then
                        'TODO 2018-12-07
                        Me.RECORD.C23_SELECT_TERM = ""
                        Me.RECORD.C16_ORG_COL_NAME = "□Value[Null]"
                    Else
                        Me.RECORD.C23_SELECT_TERM = ""
                        Me.RECORD.C16_ORG_COL_NAME = "□未設定"
                    End If
                Else
                End If

                Return True
            Catch ex As Exception
                CONSOLEWRITE("Parcer_CFValue", ex.ToString())
                Return False
            End Try
            'Return True
        End If

        Return False

    End Function
#End Region


#Region "Util"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  配列中から、Key に一致するIndex を返す。
    '''  </summary>
    ''' <param name="key">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Function getKeysindex(keyList As String(), key As String)

        If (key = Nothing) Then
            Return -1
        End If
        key = key.Trim

        Dim foo As String
        For i As Integer = 0 To keyList.Length - 1
            foo = keyList(i).Trim
            If String.Equals(foo, key) Then
                'マッチしたインデックスを返す
                Return i
            End If
        Next

        '全て不一致
        Return -1
    End Function


    ''' -----------------------------------------------------------------------------------
    Private Sub CONSOLEWRITE(foo As String, var As String)
        Console.WriteLine(foo & " : " & var)
    End Sub


#End Region



End Class
