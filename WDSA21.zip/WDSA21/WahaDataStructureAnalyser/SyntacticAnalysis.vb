﻿'----------------------------------------------------
'wtjの構文解析クラス
' 解析対象のファイルパスを受けて、構文解析を行い、結果を出力
'----------------------------------------------------

Imports System.Text.RegularExpressions


Public Class SyntacticAnalysis

    Private FilePath As String



    'タグキーワード
    Private Enum Status
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iNone
    End Enum



    '[View」テーブル定義名称を格納する。※IDをインデックスとしたストリング名称を格納する。
    Private hashViewTable = New Hashtable()




    ''' -----------------------------------------------------------------------------------
    ''' コンストラクタ
    ''' -----------------------------------------------------------------------------------
    Public Sub New()
    End Sub

    Public Sub New(ByVal strPath As String)
        If strPath Is Nothing Then
            Throw New ArgumentNullException(NameOf(strPath))
        End If
    End Sub

    ''' -----------------------------------------------------------------------------------
    ''' 初期化
    ''' -----------------------------------------------------------------------------------
    Public Sub Initialize(ByVal strPath As String)
    End Sub



    ' wtj→text へ構文変換
    'Public Sub Parce(ByVal strPath As String)
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="strPath"></param>
    Public Sub Conversion(ByVal strPath As String)

        '1.ファイル存在チェック
        If IO.File.Exists(strPath) = False Then
            Exit Sub
        End If

        '2.ファイル読込み
        Dim cReader As IO.StreamReader
        '読込ストリーマ
        cReader = New IO.StreamReader(strPath, System.Text.Encoding.Default)

        '書込ストリーマ
        Dim cWriter As IO.StreamWriter
        cWriter = New IO.StreamWriter("F:\test.txt", True)

        'ファイル読込み
        Dim intBlockID As UInteger = 0   'タグＩＤ保持用
        Dim intBlockLineCount As UInteger = 0   'タグブロック内行カウンター

        Dim strOutLine As String
        Dim strLine As String
        Dim intStatus As String
        While (cReader.Peek() >= 0)
            '１行読込み
            strLine = cReader.ReadLine

            'タグキーワードに紐ずくＩＤを取得する。
            intStatus = getStatus(strLine)
            Console.WriteLine("0>intStatus " & intStatus & ":" & strLine)

            '読込行にタグが検出された場合ブロック内カウンターを初期化する。
            'If (intBlockLineCount > 0 & intStatus <> Status.iNone) Then
            If (intStatus <> Status.iNone) Then
                '新しいタグ検知
                intBlockLineCount = 0
                intBlockID = intStatus
                'Console.WriteLine("1>intBlockLineCount=0 ")
                Console.WriteLine("1>" & intBlockID & "-" & intBlockLineCount)
            Else
                intBlockLineCount += 1
                'Console.WriteLine("2>intStatus " & intStatus & "  intBlockLineCount=" & intBlockLineCount)
                Console.WriteLine("2>" & intBlockID & "-" & intBlockLineCount)
            End If

            '構文解析　※各タグ毎の構文解析を行う
            strOutLine = Parcer(intBlockID, intBlockLineCount, strLine)

            'ファイル出力
            'cWriter.WriteLineAsync(strLine)
            cWriter.WriteLine(strLine)

        End While
        cReader.Close()

        'cWriter.FlushAsync()
        cWriter.Flush()
        cWriter.Close()


        Dim fileReader As System.IO.StreamReader
        fileReader =
        My.Computer.FileSystem.OpenTextFileReader(strPath)
        Dim stringReader As String
        stringReader = fileReader.ReadLine()
        'MsgBox("The first line of the file is " & stringReader)


        '2.タグチェック　[View],[Column],[VFilter],[CFilter]...




        '3.タグブロック内処理
        '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる




    End Sub




    '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる


    ''' <summary>
    ''' 
    ''' </summary>
    Private regPatternView As String = "^\[View\]"
    Private regPatternColumn As String = "^\[Column\]"
    Private regPatternVFilter As String = "^\[VFilter\]"
    Private regPatternCFilter As String = "^\[CFilter\]"
    Private regPatternCFValue As String = "^\[CFValue\]"
    Private regPatternSelectCondition As String = "^\[SelectCondition\]"
    Private regPatternDViewSelectCondition As String = "^\[DViewSelectCondition\]"
    Private regPatternDeleteSelectContdition As String = "^\[DeleteSelectContdition\]"
    Private regPatternRepository As String = "^\[Repository\]"
    Private regPatternProcess As String = "^\[Process\]"
    Private regPatternViewInfo As String = "^\[ViewInfo\]"
    Private regPatternLookupViewInfo As String = "^\[LookupViewInfo\]"

    Private rxView = New Regex(regPatternView, RegexOptions.Compiled)
    Private rxColumn = New Regex(regPatternColumn, RegexOptions.Compiled)
    Private rxVFilter = New Regex(regPatternVFilter, RegexOptions.Compiled)
    Private rxCFilter = New Regex(regPatternCFilter, RegexOptions.Compiled)
    Private rxCFValue = New Regex(regPatternCFValue, RegexOptions.Compiled)
    Private rxSelectCondition = New Regex(regPatternSelectCondition, RegexOptions.Compiled)
    Private rxDViewSelectCondition = New Regex(regPatternDViewSelectCondition, RegexOptions.Compiled)
    Private rxDeleteSelectContdition = New Regex(regPatternDeleteSelectContdition, RegexOptions.Compiled)
    Private rxRepository = New Regex(regPatternRepository, RegexOptions.Compiled)
    Private rxProcess = New Regex(regPatternProcess, RegexOptions.Compiled)
    Private rxViewInfo = New Regex(regPatternViewInfo, RegexOptions.Compiled)
    Private rxLookupViewInfo = New Regex(regPatternLookupViewInfo, RegexOptions.Compiled)

#Region "タグキーワードのパターンマッチ"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function getStatus(ByVal strLine As String) As UInteger

        If (strLine = Nothing) Then
            Return Status.iNone
        End If

        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        If rxView.IsMatch(strLine) Then
            Console.WriteLine("0■    " & strLine)
            Return Status.iView
        ElseIf rxColumn.IsMatch(strLine) Then
            Console.WriteLine("1■    " & strLine)
            Return Status.iColumn
        ElseIf rxVFilter.IsMatch(strLine) Then
            Console.WriteLine("2■    " & strLine)
            Return Status.iVFilter
        ElseIf rxCFilter.IsMatch(strLine) Then
            Console.WriteLine("3■    " & strLine)
            Return Status.iCFilter
        ElseIf rxCFValue.IsMatch(strLine) Then
            Console.WriteLine("4■    " & strLine)
            Return Status.iCFValue
        ElseIf rxSelectCondition.IsMatch(strLine) Then
            Console.WriteLine("5■    " & strLine)
            Return Status.iSelectCondition
        ElseIf rxDViewSelectCondition.IsMatch(strLine) Then
            Console.WriteLine("6■    " & strLine)
            Return Status.iDViewSelectCondition
        ElseIf rxDeleteSelectContdition.IsMatch(strLine) Then
            Console.WriteLine("7■    " & strLine)
            Return Status.iDeleteSelectContdition
        ElseIf rxRepository.IsMatch(strLine) Then
            Console.WriteLine("8■    " & strLine)
            Return Status.iRepository
        ElseIf rxProcess.IsMatch(strLine) Then
            Console.WriteLine("9■    " & strLine)
            Return Status.iProcess
        ElseIf rxViewInfo.IsMatch(strLine) Then
            Console.WriteLine("10■    " & strLine)
            Return Status.iViewInfo
        ElseIf rxLookupViewInfo.IsMatch(strLine) Then
            Console.WriteLine("12■    " & strLine)
            Return Status.iLookupViewInfo
        Else
            Return Status.iNone
        End If
    End Function
#End Region


    '構文解析　※各タグ毎の構文解析を行う
    'strOutLine = parcer(intBlockID, intBlockLineCount, strLine)



#Region "タグキーワードのパターンマッチ"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function Parcer(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As String

        If (strLine = Nothing) Then
            Return Status.iNone
        End If


        Select Case intBlockID
            Case Status.iView
                ParcerView(intBlockID, intBlockLineCount, strLine)
            Case Status.iColumn
            Case Status.iVFilter
            Case Status.iCFilter
            Case Status.iCFValue
            Case Status.iSelectCondition
            Case Status.iDViewSelectCondition
            Case Status.iDeleteSelectContdition
            Case Status.iRepository
            Case Status.iProcess
            Case Status.iViewInfo
            Case Status.iLookupViewInfo
            Case Status.iNone

        End Select



        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        If rxView.IsMatch(strLine) Then
            Console.WriteLine("0■    " & strLine)
            Return Status.iView
        ElseIf rxColumn.IsMatch(strLine) Then
            Return Status.iLookupViewInfo
        Else
            Return Status.iNone
        End If
    End Function
#End Region




#Region "Percer : [View]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "[View]タグブロックのパース    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function ParcerView(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As String

        If (strLine = Nothing) Then
            Return Status.iNone
        End If


        '   ParcerView(intBlockID, intBlockLineCount, strLine)

        If intBlockLineCount = 3 Then

            ' カンマ区切りで分割して配列に格納する
            'Dim columnsList As String() = strLine.Split("\t")
            Dim columnsList As String() = Split(strLine, Chr(9), , CompareMethod.Text)



            hashViewTable.Add(intBlockID, columnsList(8))

            Return columnsList(8)


        End If


        Return ""



    End Function
#End Region

End Class
