﻿'----------------------------------------------------
'wtjの構文解析クラス
' 解析対象のファイルパスを受けて、構文解析を行い、結果を出力
'----------------------------------------------------

Imports System.Text.RegularExpressions


Public Class SyntacticAnalysis

    Private FilePath As String



    Private Enum Status
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iNone
    End Enum


    Dim regPatternColumn As String = "^\\[Column\\]"







    ''' -----------------------------------------------------------------------------------
    ''' コンストラクタ
    ''' -----------------------------------------------------------------------------------
    Public Sub New()
    End Sub

    Public Sub New(ByVal strPath As String)
        If strPath Is Nothing Then
            Throw New ArgumentNullException(NameOf(strPath))
        End If
    End Sub

    ''' -----------------------------------------------------------------------------------
    ''' 初期化
    ''' -----------------------------------------------------------------------------------
    Public Sub Initialize(ByVal strPath As String)
    End Sub



    ' wtj→text へ構文変換
    'Public Sub Parce(ByVal strPath As String)
    Public Sub Conversion(ByVal strPath As String)


        '1.ファイル存在チェック
        If IO.File.Exists(strPath) = False Then
            'fileが見つからない。
            Exit Sub
        End If


        '2.ファイル読込み
        Dim strLine As String
        Dim TextFile As IO.StreamReader
        '読込ストリーマ
        TextFile = New IO.StreamReader(strPath, System.Text.Encoding.Default)

        'ファイル読込み
        strLine = TextFile.ReadLine()
        Dim intStatus As String

        Do While strLine <> Nothing
            '１行読込み
            strLine = TextFile.ReadLine

            Console.WriteLine(strLine)

            intStatus = getStatus(strLine)

            Console.WriteLine("intStatus " & intStatus)
        Loop



        TextFile.Close()




        '2.タグチェック　[View],[Column],[VFilter],[CFilter]...




        '3.タグブロック内処理
        '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる




    End Sub


    'Assemble


    '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる
















#Region "　Left メソッド　"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''     文字列の左端から指定された文字数分の文字列を返します。</summary>
    ''' <param name="stTarget">
    '''     取り出す元になる文字列。</param>
    ''' <param name="iLength">
    '''     取り出す文字数。</param>
    ''' <returns>
    '''     左端から指定された文字数分の文字列。
    '''     文字数を超えた場合は、文字列全体が返されます。</returns>
    ''' -----------------------------------------------------------------------------------
    Private Function getStatus(ByVal strLine As String) As String

        'Dim regPatternColumn = "^\\[Column\\]

        If (strLine = Nothing) Then
            Return Status.iNone
        End If



        'Dim rx = New Regex("^\\[Column\\]", RegexOptions.Compiled)
        'Dim rx = New Regex("^[Column]", RegexOptions.Compiled)
        Dim rx = New Regex("^\[Column\]", RegexOptions.Compiled)

        Dim result As Boolean = rx.IsMatch(strLine)

        If result Then
            Console.WriteLine("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
            Return Status.iColumn
        End If


        'If System.Text.RegularExpressions.Regex.IsMatch(strLine, regPatternColumn) Then
        'If System.Text.RegularExpressions.Regex.IsMatch(strLine, "^\\[Column\\]") Then
        'If System.Text.RegularExpressions.Regex.IsMatch(strLine, "^[Column]") Then
        If System.Text.RegularExpressions.Regex.IsMatch(strLine, "[Column]") Then
            'Console.WriteLine("郵便番号が含まれています")
            Return Status.iColumn
        End If

        Return Status.iNone

    End Function
#End Region



End Class
