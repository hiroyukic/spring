﻿'Public Class EnumTag
Public Class EnumTag

    'Static totalSales As Decimal = 0

    ' タグ・キーワード  Enum
    'Public Enum Status
    Public Enum Tag
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iSquareBracket
        iNone
    End Enum



End Class
