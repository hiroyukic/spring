﻿

' -----------------------------------------------------------------------------------------
' 《出力フォーマット (20130604)》
'  1 シーケンス番号	　数値文字列	15		許可	※出力シーケンス(20130604 新規追加)
'  2 タイムスタンプ	　数値文字列	15		許可	※20130418 新規追加
'  3 WTJファイル名	　　　　　　文字	128		許可	WTJファイル名称
'  4 ビューフィルタ種別	　　数値	2	0	許可	0：標準, 1：結合, 2：統合, 4：, 5：参照
'  5 ビューフィルタ種別名称	文字	8		許可
'  6 ビューフィルタ名称	　　文字	99		許可	ViewFilter名称
'  7 移送先ビューID	　数値文字列	3	0	許可	移送先・ビューID
'  8 移送先ビューテーブル名称	文字	99		許可
'  9 移送先カラムID	　数値文字列	4	0	許可	移送先・カラムID
' 10 移送先カラム長	　数値文字列	4	0	許可
' 11 移送先カラム名称	　　　　文字	99		許可	移送先・カラム名称
' 12 移送元ビューID	　数値文字列	3	0	許可	移送元・ビューID
' 13 移送元ビューテーブル名称	文字	99		許可
' 14 移送元カラムID	　数値文字列	5	0	許可	移送元・カラムID
' 15 移送元カラム長	　数値文字列	4	0	許可
' 16 移送元カラム名称	　　　　文字	256		許可	移送元・カラム名称
' 17 移送値型	　　　　　数値文字列	3	0	許可	Valタイプフラグ
' 18 移送値	　　　　　　　　文字	256		許可	実値(Value)
' 19 関数タイプ	　　　数値文字列	4	0	許可	関数ID
' 20 直接移送フラグ	　数値文字列	1	0	許可	１：直接移送
' 21 抽出条件（値）	　　　　文字	32		許可
' 22 抽出条件（演算子）	　　文字	8		許可
' 23 抽出条件（項目）	　　　　文字	64		許可
' -----------------------------------------------------------------------------------------



Public Class StructRecord

    Private ENUMTAG = New EnumTag()

    'ビューフィルタ種別名称・ディクショナリー
    Private dicVIEW_FILTER_NAME = New Dictionary(Of String, String)

    'オペレータ演算子・ディクショナリー
    Private DIC_OPERATOR_NAME = New Dictionary(Of String, String)


    Private OUT_TERM(26) As String


    'Private DIC = New CommonDirectory()

    ' タイトル行 _
    Public Const COL_TITLE As String = "0SeqNo," _
            & "1タイムスタンプ," _
            & "2格納フォルダ（業務名）," _
            & "3WTJファイル名," _
            & "4ビューフィルタ種別," _
            & "5ビューフィルタ種別名称," _
            & "6ビューフィルタ名称," _
            & "7移送先ビューID," _
            & "8移送先ビューテーブル名称," _
            & "9移送先カラムID," _
            & "10移送先カラム長," _
            & "11移送先カラム名称," _
            & "12移送元ビューID," _
            & "13移送元ビューテーブル名称," _
            & "14移送元カラムID," _
            & "15移送元カラム長," _
            & "16移送元カラム名称," _
            & "17移送値型," _
            & "18移送値," _
            & "19関数タイプ," _
            & "20直送フラグ," _
            & "21抽出条件（条件値）," _
            & "22抽出条件（比較演算子）," _
            & "23抽出条件（項目）," _
            & "24WorkDir," _
            & "25処理（0:前／1:後),"



    Public Enum columns
        c0_SEQ_NUM
        c1_MODIFY_TIME
        c2_DIR
        c3_WTJ_FILE_NAME
        c4_VIEW_FILTER_KBN
        c5_VIEW_FILTER_KBN_NAME
        c6_VIEW_FILTER_NAME
        c7_DIST_VIEW_ID
        c8_DIST_VIEW_NAME
        c9_DIST_COL_ID
        c10_DIST_COL_LEN
        c11_DIST_COL_NAME
        c12_ORG_VIEW_ID
        c13_ORG_VIEW_NAME
        c14_ORG_COL_ID
        c15_ORG_COL_LEN
        c16_ORG_COL_NAME
        c17_TRANCE_TYPE
        c18_TRANCE_VALUE
        c19_FUNCTION_TYPE
        c20_DIRECT_FLG
        c21_SELECT_CONDITION
        c22_SELECT_OPERATER
        c23_SELECT_TERM
        c24_WORK_DIR
        c25_JOB
    End Enum

    Private _seqNo As String                ' "0 SeqNo,"
    Private _timeStamp As String            ' "1 タイムスタンプ," _
    Private _parentDir As String            ' "2 格納フォルダ（業務名）,"
    Private _fileNameBody As String         ' "3 WTJファイル名,"
    Private _vFilterKind As String          ' "ビューフィルタ種別,"
    Private _vFilterKindName As String      ' "ビューフィルタ種別名称,"
    Private _vFilterName As String          ' "ビューフィルタ名称,"

    Private _distViewID As String          ' "移送先ビューID," 
    Private _distView As String            ' "移送先ビューテーブル名称," _
    Private _distColId As String            ' "移送先カラムID," _
    Private _distColLength As String        ' "移送先カラム長," _
    Private _distColName As String          ' "移送先カラム名称," _

    Private _orgViewID As String           ' "移送元ビューID," 
    Private _orgView As String             ' "移送元ビューテーブル名称," _
    Private _orgColId As String             ' "移送元カラムID," _
    Private _orgColLength As String         ' "移送元カラム長," _
    Private _orgColName As String           ' "移送元カラム名称," _

    Private _valueType As String            ' "移送値型," _
    Private _value As String                ' "移送値," _
    Private _functionType As String         ' "関数タイプ," _
    Private _directFlg As String            ' "直送フラグ," _

    Private _selectConditionVal As String   ' "抽出条件（条件値）," _	
    Private _selectConditionOpe As String   ' "抽出条件（比較演算子）,"
    Private _selectConditionAttr As String  ' "抽出条件（項目）," _
    Private _workDir As String              ' "WorkDir," _
    Private _prcessing As String            ' "処理（0:前／1:後),"


    Public Enum Tag
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iSquareBracket
        iNone
    End Enum


    Sub New()


    End Sub



    Public Property SeqNo As String
        Get
            Return _seqNo
        End Get
        Set(value As String)
            _seqNo = value
        End Set
    End Property

    Public Property TimeStamp As String
        Get
            Return _timeStamp
        End Get
        Set(value As String)
            _timeStamp = value
        End Set
    End Property

    Public Property ParentDir As String
        Get
            Return _parentDir
        End Get
        Set(value As String)
            _parentDir = value
        End Set
    End Property

    Public Property FileNameBody As String
        Get
            Return _fileNameBody
        End Get
        Set(value As String)
            _fileNameBody = value
        End Set
    End Property

    Public Property VFilterKind As String
        Get
            Return _vFilterKind
        End Get
        Set(value As String)
            _vFilterKind = value
        End Set
    End Property

    Public Property VFilterKindName As String
        Get
            Return _vFilterKindName
        End Get
        Set(value As String)
            _vFilterKindName = value
        End Set
    End Property

    Public Property VFilterName As String
        Get
            Return _vFilterName
        End Get
        Set(value As String)
            _vFilterName = value
        End Set
    End Property

    Public Property DistViewID As String
        Get
            Return _distViewID
        End Get
        Set(value As String)
            _distViewID = value
        End Set
    End Property

    Public Property DistView As String
        Get
            Return _distView
        End Get
        Set(value As String)
            _distView = value
        End Set
    End Property

    Public Property DistColId As String
        Get
            Return _distColId
        End Get
        Set(value As String)
            _distColId = value
        End Set
    End Property

    Public Property DistColLength As String
        Get
            Return _distColLength
        End Get
        Set(value As String)
            _distColLength = value
        End Set
    End Property

    Public Property DistColName As String
        Get
            Return _distColName
        End Get
        Set(value As String)
            _distColName = value
        End Set
    End Property

    Public Property OrgViewID As String
        Get
            Return _orgViewID
        End Get
        Set(value As String)
            _orgViewID = value
        End Set
    End Property

    Public Property OrgView As String
        Get
            Return _orgView
        End Get
        Set(value As String)
            _orgView = value
        End Set
    End Property

    Public Property OrgColId As String
        Get
            Return _orgColId
        End Get
        Set(value As String)
            _orgColId = value
        End Set
    End Property

    Public Property OrgColLength As String
        Get
            Return _orgColLength
        End Get
        Set(value As String)
            _orgColLength = value
        End Set
    End Property

    Public Property OrgColName As String
        Get
            Return _orgColName
        End Get
        Set(value As String)
            _orgColName = value
        End Set
    End Property

    Public Property ValueType As String
        Get
            Return _valueType
        End Get
        Set(value As String)
            _valueType = value
        End Set
    End Property

    Public Property Value As String
        Get
            Return _value
        End Get
        Set(value As String)
            _value = value
        End Set
    End Property

    Public Property FunctionType As String
        Get
            Return _functionType
        End Get
        Set(value As String)
            _functionType = value
        End Set
    End Property

    Public Property DirectFlg As String
        Get
            Return _directFlg
        End Get
        Set(value As String)
            _directFlg = value
        End Set
    End Property

    Public Property SelectConditionVal As String
        Get
            Return _selectConditionVal
        End Get
        Set(value As String)
            _selectConditionVal = value
        End Set
    End Property

    Public Property SelectConditionOpe As String
        Get
            Return _selectConditionOpe
        End Get
        Set(value As String)
            _selectConditionOpe = value
        End Set
    End Property

    Public Property SelectConditionAttr As String
        Get
            Return _selectConditionAttr
        End Get
        Set(value As String)
            _selectConditionAttr = value
        End Set
    End Property

    Public Property WorkDir As String
        Get
            Return _workDir
        End Get
        Set(value As String)
            _workDir = value
        End Set
    End Property

    Public Property Prcessing As String
        Get
            Return _prcessing
        End Get
        Set(value As String)
            _prcessing = value
        End Set
    End Property



    'Public Function Println(tagStatus As UInteger) As String
    Public Function getLine(tagStatus As UInteger) As String

        Dim strOutLine As String = ""

        '現在のタグのブロックＩＤによって、構文の処理を変える
        Select Case tagStatus
            'Case Status.iView
            '    ParcerView(intBlockID, intBlockLineCount, strLine)
            '    Return Nothing
            'Case Status.iColumn
            '    '[View]ブロックの次には必ず[Column]ブロックが定義される。
            '    ParcerColum(intBlockID, intBlockLineCount, strLine)
            '    Return Nothing

            'Case Me.Tag.iVFilter

            Case Tag.iVFilter
                'ビューフィルタ1件の情報
                '[VFilter]ブロック  ビューフィルタ定義
                OUT_TERM(columns.c0_SEQ_NUM) = Me.SeqNo
                OUT_TERM(columns.c1_MODIFY_TIME) = Me.TimeStamp
                OUT_TERM(columns.c2_DIR) = Me._parentDir
                OUT_TERM(columns.c3_WTJ_FILE_NAME) = Me.FileNameBody
                OUT_TERM(columns.c4_VIEW_FILTER_KBN) = Me.VFilterName
                OUT_TERM(columns.c5_VIEW_FILTER_KBN_NAME) = Me.VFilterKindName
                OUT_TERM(columns.c6_VIEW_FILTER_NAME) = Me.VFilterName
                OUT_TERM(columns.c7_DIST_VIEW_ID) = Me.DistViewID
                OUT_TERM(columns.c8_DIST_VIEW_NAME) = Me.DistView
                OUT_TERM(columns.c9_DIST_COL_ID) = ""
                OUT_TERM(columns.c10_DIST_COL_LEN) = ""
                OUT_TERM(columns.c11_DIST_COL_NAME) = ""
                OUT_TERM(columns.c12_ORG_VIEW_ID) = ""
                OUT_TERM(columns.c13_ORG_VIEW_NAME) = ""
                OUT_TERM(columns.c14_ORG_COL_ID) = ""
                OUT_TERM(columns.c15_ORG_COL_LEN) = ""
                OUT_TERM(columns.c16_ORG_COL_NAME) = ""
                OUT_TERM(columns.c17_TRANCE_TYPE) = ""
                OUT_TERM(columns.c18_TRANCE_VALUE) = ""
                OUT_TERM(columns.c19_FUNCTION_TYPE) = ""
                OUT_TERM(columns.c20_DIRECT_FLG) = ""
                OUT_TERM(columns.c21_SELECT_CONDITION) = ""
                OUT_TERM(columns.c22_SELECT_OPERATER) = ""
                OUT_TERM(columns.c23_SELECT_TERM) = ""
                OUT_TERM(columns.c24_WORK_DIR) = ""
                OUT_TERM(columns.c25_JOB) = ""

                '出力行・整形
                strOutLine = getFormatLine(OUT_TERM)

                Return strOutLine



            Case Tag.iViewInfo
                '[ViewInfo]ブロック  ビューフィルタ定義

                'Dim filterKindName As String
                'Try
                '    Me.VFilterKindName = Me.dicVIEW_FILTER_NAME(Me.VFilterKind)
                '    Me.VFilterKindName = Me.DIC.getAttr(Me.VFilterKind)
                '    ssssssssssssssss
                'Catch ex As Exception
                '    Me.VFilterKindName = "-"
                'End Try

                OUT_TERM(columns.c0_SEQ_NUM) = Me.SeqNo
                OUT_TERM(columns.c1_MODIFY_TIME) = Me.TimeStamp
                OUT_TERM(columns.c2_DIR) = Me._parentDir
                OUT_TERM(columns.c3_WTJ_FILE_NAME) = Me.FileNameBody
                OUT_TERM(columns.c4_VIEW_FILTER_KBN) = Me.VFilterName
                OUT_TERM(columns.c5_VIEW_FILTER_KBN_NAME) = Me.VFilterKindName
                OUT_TERM(columns.c6_VIEW_FILTER_NAME) = Me.VFilterName
                OUT_TERM(columns.c7_DIST_VIEW_ID) = Me.DistViewID
                OUT_TERM(columns.c8_DIST_VIEW_NAME) = Me.DistView
                OUT_TERM(columns.c9_DIST_COL_ID) = ""
                OUT_TERM(columns.c10_DIST_COL_LEN) = ""
                OUT_TERM(columns.c11_DIST_COL_NAME) = ""
                OUT_TERM(columns.c12_ORG_VIEW_ID) = Me.OrgViewID
                OUT_TERM(columns.c13_ORG_VIEW_NAME) = Me.OrgView
                OUT_TERM(columns.c14_ORG_COL_ID) = ""
                OUT_TERM(columns.c15_ORG_COL_LEN) = ""
                OUT_TERM(columns.c16_ORG_COL_NAME) = ""
                OUT_TERM(columns.c17_TRANCE_TYPE) = ""
                OUT_TERM(columns.c18_TRANCE_VALUE) = ""
                OUT_TERM(columns.c19_FUNCTION_TYPE) = ""
                OUT_TERM(columns.c20_DIRECT_FLG) = ""
                OUT_TERM(columns.c21_SELECT_CONDITION) = ""
                OUT_TERM(columns.c22_SELECT_OPERATER) = ""
                OUT_TERM(columns.c23_SELECT_TERM) = ""
                OUT_TERM(columns.c24_WORK_DIR) = Me.WorkDir
                OUT_TERM(columns.c25_JOB) = "[ViewInfo]"


                '出力行・整形
                strOutLine = getFormatLine(OUT_TERM)

                Return strOutLine

            Case Tag.iSelectCondition
                '[SelectCondition]ブロック  ※抽出条件
                Dim ope As String
                Try
                    ' 1:≠, 2:＜, 3:＞, 4:≦, 5:≧, 6:中間一致, 7:前方一致, 8:後方一致
                    'ope = Me.DIC_OPERATOR_NAME(Me.SelectConditionVal)
                    'ope = Me.DIC_OPERATOR_NAME(Me.SelectConditionOpe)

                    'ope = Me.DIC.GetAttr("OPERATOR", Me.SelectConditionOpe)


                Catch ex As Exception
                    ope = "-"
                End Try

                OUT_TERM(columns.c0_SEQ_NUM) = Me.SeqNo
                OUT_TERM(columns.c1_MODIFY_TIME) = Me.TimeStamp
                OUT_TERM(columns.c2_DIR) = Me._parentDir
                OUT_TERM(columns.c3_WTJ_FILE_NAME) = Me.FileNameBody
                OUT_TERM(columns.c4_VIEW_FILTER_KBN) = Me.VFilterName
                OUT_TERM(columns.c5_VIEW_FILTER_KBN_NAME) = Me.VFilterKindName
                OUT_TERM(columns.c6_VIEW_FILTER_NAME) = Me.VFilterName
                OUT_TERM(columns.c7_DIST_VIEW_ID) = Me.DistViewID
                OUT_TERM(columns.c8_DIST_VIEW_NAME) = Me.DistView
                OUT_TERM(columns.c9_DIST_COL_ID) = ""
                OUT_TERM(columns.c10_DIST_COL_LEN) = ""
                OUT_TERM(columns.c11_DIST_COL_NAME) = ""
                OUT_TERM(columns.c12_ORG_VIEW_ID) = Me.OrgViewID
                OUT_TERM(columns.c13_ORG_VIEW_NAME) = Me.OrgView
                OUT_TERM(columns.c14_ORG_COL_ID) = ""
                OUT_TERM(columns.c15_ORG_COL_LEN) = ""
                OUT_TERM(columns.c16_ORG_COL_NAME) = ""
                OUT_TERM(columns.c17_TRANCE_TYPE) = ""
                OUT_TERM(columns.c18_TRANCE_VALUE) = ""
                OUT_TERM(columns.c19_FUNCTION_TYPE) = ""
                OUT_TERM(columns.c20_DIRECT_FLG) = ""
                OUT_TERM(columns.c21_SELECT_CONDITION) = Me.SelectConditionVal
                OUT_TERM(columns.c22_SELECT_OPERATER) = Me._selectConditionOpe
                OUT_TERM(columns.c23_SELECT_TERM) = Me.SelectConditionAttr
                OUT_TERM(columns.c24_WORK_DIR) = Me.WorkDir
                OUT_TERM(columns.c25_JOB) = "[SelectCondition]"


                '出力行・整形
                strOutLine = getFormatLine(OUT_TERM)

                Return strOutLine


           '＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
           '＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
           '＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊

            Case Tag.iCFValue

                '[CFValue]ブロック  ※アトリビュート（移送元、移送先）
                Dim ope As String
                Try
                    ' 1:≠, 2:＜, 3:＞, 4:≦, 5:≧, 6:中間一致, 7:前方一致, 8:後方一致
                    'ope = Me.DIC_OPERATOR_NAME(Me.SelectConditionVal)
                    'ope = Me.DIC_OPERATOR_NAME(Me.SelectConditionOpe)
                    'ope = Me.DIC("OPERATOR", Me.SelectConditionOpe)
                Catch ex As Exception
                    ope = "-"
                End Try



                OUT_TERM(columns.c0_SEQ_NUM) = Me.SeqNo
                OUT_TERM(columns.c1_MODIFY_TIME) = Me.TimeStamp
                OUT_TERM(columns.c2_DIR) = Me._parentDir
                OUT_TERM(columns.c3_WTJ_FILE_NAME) = Me.FileNameBody
                OUT_TERM(columns.c4_VIEW_FILTER_KBN) = Me.VFilterName
                OUT_TERM(columns.c5_VIEW_FILTER_KBN_NAME) = Me.VFilterKindName
                OUT_TERM(columns.c6_VIEW_FILTER_NAME) = Me.VFilterName
                OUT_TERM(columns.c7_DIST_VIEW_ID) = Me.DistViewID
                OUT_TERM(columns.c8_DIST_VIEW_NAME) = Me.DistView
                OUT_TERM(columns.c9_DIST_COL_ID) = Me.DistColId
                OUT_TERM(columns.c10_DIST_COL_LEN) =
                OUT_TERM(columns.c11_DIST_COL_NAME) = ""

                OUT_TERM(columns.c12_ORG_VIEW_ID) = Me.OrgViewID
                OUT_TERM(columns.c13_ORG_VIEW_NAME) = Me.OrgView
                OUT_TERM(columns.c14_ORG_COL_ID) = Me.OrgColId
                OUT_TERM(columns.c15_ORG_COL_LEN) = Me.OrgColLength
                OUT_TERM(columns.c16_ORG_COL_NAME) = Me.OrgColName
                OUT_TERM(columns.c17_TRANCE_TYPE) = Me.ValueType
                OUT_TERM(columns.c18_TRANCE_VALUE) = Me.Value
                OUT_TERM(columns.c19_FUNCTION_TYPE) = Me.FunctionType
                OUT_TERM(columns.c20_DIRECT_FLG) = Me.DirectFlg
                OUT_TERM(columns.c21_SELECT_CONDITION) = ""
                OUT_TERM(columns.c22_SELECT_OPERATER) = ""
                OUT_TERM(columns.c23_SELECT_TERM) = ""
                OUT_TERM(columns.c24_WORK_DIR) = Me.WorkDir
                OUT_TERM(columns.c25_JOB) = "[CFValue]"



                '出力行・整形
                strOutLine = getFormatLine(OUT_TERM)

                Return strOutLine


            'Case Status.iDeleteSelectContdition
            '    Return Nothing
            'Case Status.iRepository
            '    Return Nothing
            'Case Status.iProcess
            '    Return Nothing
            'Case Status.iLookupViewInfo
            '    Return Nothing
            Case Tag.iNone
                Return Nothing

        End Select




        Return Nothing

    End Function



    Public Sub checkPrint(iStatus As UInteger)

        Dim line As String = Me.getLine(iStatus)
        Console.WriteLine("iStatus>>> " & iStatus & "---" & line)

    End Sub


    Private Function getFormatLine(columnArray() As String)

        Dim csvForm As String = ""

        For Each col As String In columnArray
            csvForm = csvForm & col & ","
        Next

        Debug.Print("=>>>>>>>" & csvForm)

        Return csvForm

    End Function

End Class
