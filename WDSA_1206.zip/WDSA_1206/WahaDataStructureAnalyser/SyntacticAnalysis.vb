﻿'----------------------------------------------------
'wtjの構文解析クラス
' 解析対象のファイルパスを受けて、構文解析を行い、結果を出力
'----------------------------------------------------

Imports System.Text.RegularExpressions


Public Class SyntacticAnalysis

    Private FilePath As String

    Private intTotalLineCount As UInteger

    Private dict As CommonDirectory

    ' Directory用・関数キーワード
    Const FUNCT As String = "FUNCT"
    Const OPE As String = "OPERATOR"
    Const VIEW_FILTER_CLASS As String = "VIEW_FILTER_CLASS"



    'ファイルの生成日時
    Private FILE_CREAT_TIME As String
    'ファイルの格納ディレクトリ  ※直近親ディレクトリ
    Private FILE_PARENT_DIR As String

    Private FILE_NAME_BODY As String


    '出力属性情報クラス
    Private RECORD As StructRecord


    'ビューフィルタ構造体 　※'[VFilter] [CFilter] [CFValue]
    Private Structure STRUCT_VIEW_FILTER
        Public AtrributeList As String()          ' 属性のリスト配列

        '[VFilter] ビューフィルタ定義
        Public VF1Kind As Integer           'ビューフィルタ区分
        Public VF1KindName As String        'ビューフィルタ区分名称
        Public VF1FilterId As Integer             '
        Public VF1FilterName As String            '
        '[CFilter] 移送先・属性ＩＤ
        Public CF2FiltererOutViewId As Integer    '
        Public CF2FilterOutColId As Integer       '
        '[CFValue]
        Public CFV3ValueViewID As Integer         ' 移送元・ビューID
        Public CFV3ValueValue As String           ' 移送元・移送値
        Public CFV3ValueSFType                    ' 関数タイプ
        Public CFV3ValueRealValueType             ' 実値型
        Public CFV3ValuelikColID                  ' 移送元・カラムID
        Public CFV3ValueID                        ' a
        Public CFV3ValueIsRoot                    ' ルートフラグ
        Public CFV3ValueChildIDs As String        ' パラメータ
        '二項比較子
        Public CFV3ValueValueType As String       'ValueType
        Public CFV3ValueSetValueType As String    'SetValueType
        Public CFV3ValueObjType As String         'ObjType
        '
        Public CFV3ValueName As String            '
    End Structure

    Private recordViewFilter As STRUCT_VIEW_FILTER

    ' タグ・キーワード  Enum
    Private Enum Status
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iSquareBracket
        iNone
    End Enum

    'タグ・キーワード  ストリングパターン
    Private regPatternView As String = "^\[View\]"
    Private regPatternColumn As String = "^\[Column\]"
    Private regPatternVFilter As String = "^\[VFilter\]"
    Private regPatternCFilter As String = "^\[CFilter\]"
    Private regPatternCFValue As String = "^\[CFValue\]"
    Private regPatternSelectCondition As String = "^\[SelectCondition\]"
    Private regPatternDViewSelectCondition As String = "^\[DViewSelectCondition\]"
    Private regPatternDeleteSelectContdition As String = "^\[DeleteSelectContdition\]"
    Private regPatternRepository As String = "^\[Repository\]"
    Private regPatternProcess As String = "^\[Process\]"
    Private regPatternViewInfo As String = "^\[ViewInfo\]"
    Private regPatternLookupViewInfo As String = "^\[LookupViewInfo\]"
    Private regPatternSquareBracket As String = "^\["
    '----------------------------------------------------------------------------------
    Private rxView = New Regex(regPatternView, RegexOptions.Compiled)
    Private rxColumn = New Regex(regPatternColumn, RegexOptions.Compiled)
    Private rxVFilter = New Regex(regPatternVFilter, RegexOptions.Compiled)
    Private rxCFilter = New Regex(regPatternCFilter, RegexOptions.Compiled)
    Private rxCFValue = New Regex(regPatternCFValue, RegexOptions.Compiled)
    Private rxSelectCondition = New Regex(regPatternSelectCondition, RegexOptions.Compiled)
    Private rxDViewSelectCondition = New Regex(regPatternDViewSelectCondition, RegexOptions.Compiled)
    Private rxDeleteSelectContdition = New Regex(regPatternDeleteSelectContdition, RegexOptions.Compiled)
    Private rxRepository = New Regex(regPatternRepository, RegexOptions.Compiled)
    Private rxProcess = New Regex(regPatternProcess, RegexOptions.Compiled)
    Private rxViewInfo = New Regex(regPatternViewInfo, RegexOptions.Compiled)
    Private rxLookupViewInfo = New Regex(regPatternLookupViewInfo, RegexOptions.Compiled)
    Private rxSquareBracket = New Regex(regPatternSquareBracket, RegexOptions.Compiled)

    'Dictionaly 分別キーワード
    Private Const VIEW As String = "VIEW"
    Private Const COLUMN As String = "COLUMN"
    Private Const COLUMN_LENGTH As String = "COLUMN_LENGTH"

    '[View」テーブル定義名称を格納する。※IDをインデックスとしたストリング名称を格納する。
    'Private hashViewTable = New Hashtable()
    Private hashViewTable

    '[Column」テーブル属性名称を格納する。※IDをインデックスとしたテーブルの属性名称を格納する。
    'Private hashColumn
    'Private hashColumnLength


    'TagBlock
    Private intTAG_BLOCK_ID As String
    'Setter/Getter
    Private Function GetTAG_BLOCK_ID() As String
        Return intTAG_BLOCK_ID
    End Function
    Private Function SetTAG_BLOCK_ID(ByVal val As String)
        intTAG_BLOCK_ID = val
    End Function



    'ViewID
    Private intVIEW_ID As String
    'Setter/Getter
    Private Function GetVIEW_ID() As String
        Return intVIEW_ID
    End Function
    Private Function SetVIEW_ID(ByVal val As String)
        intVIEW_ID = val
    End Function

    ''' -----------------------------------------------------------------------------------
    ''' コンストラクタ
    ''' -----------------------------------------------------------------------------------
    Public Sub New()
    End Sub

    Public Sub New(ByVal strPath As String)
        If strPath Is Nothing Then
            Throw New ArgumentNullException(NameOf(strPath))
        End If
    End Sub

    ''' -----------------------------------------------------------------------------------
    ''' 初期化
    ''' -----------------------------------------------------------------------------------
    Public Sub Initialize(ByVal strPath As String)
    End Sub


    '■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    ' wtj→text へ構文変換
    ' ファイル名称を引き受け、読み込みながら構文解析を行う。
    'Public Sub Parce(ByVal strPath As String)
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="strPath"></param>
    Public Sub Conversion(ByVal strPath As String)

        'ハッシュテーブル初期化　※wtj毎に初期化
        hashViewTable = New Hashtable()

        'hashColumn = New Hashtable()

        'hashColumnLength = New Hashtable()

        'hashViewTable.GetHashCode()


        'ディクショナリー初期化
        dict = New CommonDirectory


        '1.ファイル存在チェック
        If IO.File.Exists(strPath) = False Then
            Exit Sub
        End If

        'ファイルのタイムスタンプ
        Me.FILE_CREAT_TIME = System.IO.File.GetCreationTime(strPath)
        'ファイル格納ディレクトリ  ※直近親ディレクトリ →業務名
        'Me.FILE_PARENT_DIR = System.IO.Directory.GetCurrentDirectory(strPath)
        'Me.FILE_NAME_BODY = System.IO.Directory.GetCurrentDirectory(strPath)
        'Me.FILE_NAME_BODY = System.IO.Path.GetFileName(strPath)


        '2.ファイル読込み
        Dim cReader As IO.StreamReader
        '読込ストリーマ
        cReader = New IO.StreamReader(strPath, System.Text.Encoding.Default)

        '書込ストリーマ
        'Dim cWriter As IO.StreamWriter
        'cWriter = New IO.StreamWriter("F:\test.txt", True)
        Using cWriter = New IO.StreamWriter(New IO.FileStream("D:\test.txt", IO.FileMode.Create))
            'Using cWriter = New IO.StreamWriter(New IO.FileStream("F:\test.txt", IO.FileMode.Create))

            'タイトル
            cWriter.WriteLine(StructRecord.COL_TITLE)

            ' ---------------------------------
            ' 出力レコードクラスのインスタンス化
            ' ---------------------------------
            Me.RECORD = New StructRecord

            Try
                Me.RECORD.ParentDir = System.IO.Path.GetDirectoryName(strPath)
                Me.RECORD.FileNameBody = System.IO.Path.GetFileName(strPath)

            Catch ex As Exception
                'Console.WriteLine(">>>>>>>>>>>>>>>>>>>:" & strPath)

            End Try



            'ファイル読込み
            Dim intBlockID As UInteger = 0   'タグＩＤ保持用
            Dim intBlockLineCount As UInteger = 0   'タグブロック内行カウンター

            Dim strOutLine As String
            Dim strLine As String
            Dim intStatus As String

            Dim intRowCount As Integer = 0

            While (cReader.Peek() >= 0)
                intRowCount += 1

                Me.RECORD.SeqNo += 1


                '１行読込み
                strLine = cReader.ReadLine

                'タグキーワードに紐ずくＩＤを取得する。
                intStatus = getStatus(strLine)
                'Console.WriteLine("0>intStatus " & intStatus & ":" & strLine)



                '読込行にタグが検出された場合ブロック内カウンターを初期化する。
                'If (intBlockLineCount > 0 & intStatus <> Status.iNone) Then
                If (intStatus <> Status.iNone) Then
                    '新しいタグ検知
                    intBlockLineCount = 0
                    intBlockID = intStatus
                    Me.CONSOLEWRITE("L263 新しいBlockID ", intBlockID)
                Else
                    intBlockLineCount += 1
                End If

                ' -------------------------------------
                '構文解析　※各タグ毎の構文解析を行う
                ' -------------------------------------
                strOutLine = Parcer(intBlockID, intBlockLineCount, strLine)

                'ファイル出力
                If (strOutLine <> Nothing) Then
                    Me.CONSOLEWRITE("L275 IN ", strLine)
                    Me.CONSOLEWRITE("L276 OUT", strOutLine)

                    cWriter.WriteLine(strOutLine)
                End If


            End While
            cReader.Close()

            cWriter.Flush()
        End Using
        'cWriter.FlushAsync()
        'cWriter.Close()

        'Console.WriteLine("  >" & hashColumn.ToString())
        ' キーの列挙
        'For Each key As String In hashColumn.Keys
        '    Dim val As String = hashColumn(key)
        '    Me.CONSOLEWRITE(key, val)
        'Next

        '*************************
        dict.print()


        'Dim fileReader As System.IO.StreamReader
        'fileReader =
        'My.Computer.FileSystem.OpenTextFileReader(strPath)
        'Dim stringReader As String
        'stringReader = fileReader.ReadLine()
        MsgBox("The first line of the file is ")


        '2.タグチェック　[View],[Column],[VFilter],[CFilter]...


        '3.タグブロック内処理
        '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる

    End Sub




    '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる



    '構文解析　※各タグ毎の構文解析を行う
    'strOutLine = parcer(intBlockID, intBlockLineCount, strLine)









#Region "タグキーワードのパターンマッチ"
    '■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function Parcer(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As String

        If (strLine = Nothing) Then
            Return Nothing
        End If

        'Select Case intBlockID
        '現在のタグのブロックＩＤによって、構文の処理を変える
        Dim retLine = ""
        Select Case GetTAG_BLOCK_ID()
            Case Status.iView
                CONSOLEWRITE("Parcer", "■iView")
                Parcer_View(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iColumn
                CONSOLEWRITE("Parcer", "■iColumn")
                '[View]ブロックの次には必ず[Column]ブロックが定義される。
                Parcer_Colum(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iVFilter
                '[VFilter]ブロック  ビューフィルタ定義
                CONSOLEWRITE("Parcer", "■iVFilter")
                Parcer_VFilter(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iViewInfo
                '[ViewInfo]ブロック  ビューフィルタ定義
                CONSOLEWRITE("Parcer", "■ViewInfo")
                If Parcer_ViewInfo(intBlockID, intBlockLineCount, strLine) Then
                    'If intBlockLineCount >= 2 Then
                    Return Me.RECORD.getLine(Status.iViewInfo)
                Else
                    Return Nothing
                End If
            Case Status.iSelectCondition
                '[SelectCondition]ブロック  抽出条件
                CONSOLEWRITE("Parcer", "■SelectionCondition")
                If Parcer_SelectCondition(intBlockID, intBlockLineCount, strLine) Then
                    Return Me.RECORD.getLine(Status.iSelectCondition)
                Else
                    Return Nothing
                End If




            ' ================ CFilter ================
            Case Status.iCFilter
                CONSOLEWRITE("Parcer", "■CFilter")
                Parcer_CFilter(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iCFValue
                CONSOLEWRITE("Parcer", "■CFValue")
                If Parcer_CFValue(intBlockID, intBlockLineCount, strLine) Then
                    Return Me.RECORD.getLine(Status.iCFValue)
                Else
                    Return Nothing
                End If


            Case Status.iDViewSelectCondition
                Return Nothing
            Case Status.iDeleteSelectContdition
                Return Nothing
            Case Status.iRepository
                Return Nothing
            Case Status.iProcess
                Return Nothing
            Case Status.iLookupViewInfo
                Return Nothing
                'Case Status.iNone
                '    Return Nothing

        End Select


        'Return Status.iNone


        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        '        If rxView.IsMatch(strLine) Then
        '        Console.WriteLine("0■    " & strLine)
        '        Return Status.iView
        '        ElseIf rxColumn.IsMatch(strLine) Then
        '        Return Status.iLookupViewInfo
        '        Else
        '        Return Status.iNone
        '        End If

    End Function
#End Region




#Region "タグキーワードのパターンマッチ"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function getStatus(ByVal strLine As String) As UInteger

        If (strLine = Nothing) Then
            Return Status.iNone
        End If

        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        If rxView.IsMatch(strLine) Then
            SetTAG_BLOCK_ID(Status.iView)
            Return Status.iView
        ElseIf rxColumn.IsMatch(strLine) Then
            SetTAG_BLOCK_ID(Status.iColumn)
            Return Status.iColumn
        ElseIf rxVFilter.IsMatch(strLine) Then
            SetTAG_BLOCK_ID(Status.iVFilter)
            Return Status.iVFilter
        ElseIf rxCFilter.IsMatch(strLine) Then
            'Console.WriteLine("3■    " & strLine)
            SetTAG_BLOCK_ID(Status.iCFilter)
            Return Status.iCFilter
        ElseIf rxCFValue.IsMatch(strLine) Then
            'Console.WriteLine("4■    " & strLine)
            SetTAG_BLOCK_ID(Status.iCFValue)
            Return Status.iCFValue
        ElseIf rxSelectCondition.IsMatch(strLine) Then
            'Console.WriteLine("5■    " & strLine)
            SetTAG_BLOCK_ID(Status.iSelectCondition)
            Return Status.iSelectCondition
        ElseIf rxDViewSelectCondition.IsMatch(strLine) Then
            'Console.WriteLine("6■    " & strLine)
            SetTAG_BLOCK_ID(Status.iDViewSelectCondition)
            Return Status.iDViewSelectCondition
        ElseIf rxDeleteSelectContdition.IsMatch(strLine) Then
            'Console.WriteLine("7■    " & strLine)
            SetTAG_BLOCK_ID(Status.iDeleteSelectContdition)
            Return Status.iDeleteSelectContdition
        ElseIf rxRepository.IsMatch(strLine) Then
            'Console.WriteLine("8■    " & strLine)
            SetTAG_BLOCK_ID(Status.iRepository)
            Return Status.iRepository
        ElseIf rxProcess.IsMatch(strLine) Then
            'Console.WriteLine("9■    " & strLine)
            SetTAG_BLOCK_ID(Status.iProcess)
            Return Status.iProcess
        ElseIf rxViewInfo.IsMatch(strLine) Then
            'Console.WriteLine("10■    " & strLine)
            SetTAG_BLOCK_ID(Status.iViewInfo)
            Return Status.iViewInfo
        ElseIf rxLookupViewInfo.IsMatch(strLine) Then
            'Console.WriteLine("12■    " & strLine)
            SetTAG_BLOCK_ID(Status.iLookupViewInfo)
            Return Status.iLookupViewInfo
        ElseIf rxSquareBracket.IsMatch(strLine) Then
            'Console.WriteLine("13■    " & strLine)
            SetTAG_BLOCK_ID(Status.iSquareBracket)
            Return Status.iSquareBracket
        Else
            Return Status.iNone
        End If


    End Function
#End Region


#Region "Percer : [View]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  ①　[View]タグブロックのパース 
    '''  ※View ブロックからＩ／Ｏテーブル名称を取得し、Viewハッシュにストアする。
    '''  ※タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub Parcer_View(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If

        Dim columnsList As String()

        Try
            If intBlockLineCount = 2 Then
                ' カンマ区切りで分割して配列に格納する
                columnsList = Split(strLine, Chr(9), , CompareMethod.Text)
                'ViewハッシュにテーブルＩＤとテーブル名称を登録
                If columnsList.Length > 7 Then
                    Dim viewID As String = columnsList(7)    'View ID
                    Dim viewName As String = columnsList(8)  'View 名称
                    SetVIEW_ID(viewID)

                    'View ID をハッシュ登録
                    'hashViewTable.Add(GetVIEW_ID(), viewName)

                    ' ★★★★★★★★★★★★★★★★ 
                    dict.SetAttr(VIEW, GetVIEW_ID(), viewName)

                End If
            End If
        Catch ex As System.AggregateException
            MessageBox.Show(ex.StackTrace, "xxxxxxxxxxxx")
        End Try
    End Sub
#End Region



#Region "Percer : [View]-[Colum]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  ②　[Colum]タグブロックのパース 
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub Parcer_Colum(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If

        Dim columnsList As String()
        'If intBlockLineCount = 3 Then
        If intBlockLineCount >= 2 Then
            ' カンマ区切りで分割して配列に格納する
            columnsList = Split(strLine, Chr(9), , CompareMethod.Text)

            'ViewハッシュにテーブルＩＤとテーブル名称を登録
            If columnsList.Length > 6 Then
                Dim columnName As String = columnsList(5)   '属性名称
                Dim columnLength As String = columnsList(6) '属性長
                Dim columnID As String = columnsList(10)    '属性ID

                Dim key As String = GetVIEW_ID() & "_" & columnID

                '属性名称、属性長をハッシュにストア
                'hashColumn.Add(key, columnName)
                'hashColumnLength.Add(key, columnLength)


                ' ★★★★★★★★★★★★★★★★ 
                Me.dict.SetAttr(COLUMN, GetVIEW_ID, columnID, columnName)
                Me.dict.SetAttr(COLUMN_LENGTH, GetVIEW_ID, columnID, columnLength)


            End If
        End If
    End Sub
#End Region




#Region "Percer : [VFilter]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  [View]タグブロックのパース 
    '''  
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub Parcer_VFilter(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If

        Try

            Dim columns As String() = Split(strLine, Chr(9), , CompareMethod.Text)

            'If intBlockLineCount = 3 Then

            If intBlockLineCount = 1 Then
                ' [1]タイトル行
                ' カンマ区切りで分割して配列に格納する
                columns = Split(strLine, Chr(9), , CompareMethod.Text)

                ''ViewハッシュにテーブルＩＤとテーブル名称を登録
                'If columnsList.Length > 6 Then
                '    Dim columnName As String = columnsList(5)   '属性名称
                'End If

                'ビューフィルタ構造体 初期化
                recordViewFilter = New STRUCT_VIEW_FILTER With {
                        .AtrributeList = columns
                    }
                'ElseIf intBlockLineCount = 3 Then
                'ElseIf intBlockLineCount = 2 Then
            ElseIf intBlockLineCount >= 2 Then
                ' [2]フィルター定義｛フィルター種別、フィルター名称｝
                ' カンマ区切りで分割して配列に格納する
                columns = Split(strLine, Chr(9), , CompareMethod.Text)

                '配列中キーワードにマッチしたインデックス
                Dim indexKind As Integer = getKeysindex(recordViewFilter.AtrributeList, "Kind")
                Dim indexId As Integer = getKeysindex(recordViewFilter.AtrributeList, "ID")
                Dim indexrName As String = getKeysindex(recordViewFilter.AtrributeList, "Name")

                'レコードオブジェクトに設定
                Me.recordViewFilter.VF1Kind = columns(indexKind)
                Me.recordViewFilter.VF1FilterId = columns(indexId)
                Me.recordViewFilter.VF1FilterName = columns(indexrName)

                Me.RECORD.VFilterKind = columns(indexKind)
                Me.RECORD.VFilterName = columns(indexrName)
                'ヴューフィルタの名称は、StructRecore中にて設定するためここでは不定
                'Me.RECORD.VFilterKindName = columns(indexKind)
                Me.RECORD.VFilterName = columns(indexrName)


            End If


            'getKeysindex


            ''ビューフィルタ構造体 初期化
            'recordViewFilter = New STRUCT_VIEW_FILTER With {
            '    .AtrributeList = columns,
            '    .VF1Kind = 2,          'ビューフィルタ区分
            '    .VF1KindName = 2,      'ビューフィルタ区分名称
            '    .VF1FilterId = 2,
            '    .VF1FilterName = "NNNNNNN"
            '}


        Catch ex As System.Exception
            MessageBox.Show(ex.StackTrace, "xxxxxxxxxxxx")
        End Try
    End Sub
#End Region


#Region "Percer : [VFilter]-[VewInfo]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  [VewInfo]タグブロックのパース 
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Function Parcer_ViewInfo(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1

        Dim arryColumns As String()
        '■■■■■■■■■■■■■■■■■■■■■■■■
        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        If intBlockLineCount > 1 Then
            ' カンマ区切りで分割して配列に格納する
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)

            Dim strViewKind = arryColumns(0).Trim   '0:入力ファイル、1:分割ファイル
            Dim strViewId = arryColumns(1).Trim     '前処理[0]、後処理[1]

            Dim strInputViewId As String = ""       '入力ビューID
            Dim strInputView As String = ""         '入力ビュー名称
            Dim strOutputViewId As String = ""      '出力ビューID
            Dim strOutputView As String = ""        '出力ビュー名称
            '■■■■■■■■■■■■■■■■■■■■■■■■
            ' todo
            If (strViewKind.StartsWith("0")) Then
                '①入力情報
                strInputViewId = strViewId
                'strInputView = CStr(hashViewTable(strViewId))
                strInputView = CStr(dict.GetAttr(VIEW, strViewId))

                strOutputViewId = "-"
                strOutputView = "-"

                '移送元ビューID/名称
                Me.RECORD.OrgViewID = strViewId
                Me.RECORD.OrgView = strInputView
                '移送先ビューID/名称
                Me.RECORD.DistViewID = "-"
                Me.RECORD.DistView = "-"
                Return True
            Else
                '②出力情報
                strOutputViewId = strViewId
                'strOutputView = CStr(hashViewTable(strViewId))

                ' ★★★★★★★★★★★★★★★★ 
                strOutputView = CStr(dict.GetAttr(VIEW, strViewId))

                '移送先ビューID/名称
                Me.RECORD.DistViewID = strViewId
                'Me.RECORD.DistView = CStr(hashViewTable(strViewId))

                ' ★★★★★★★★★★★★★★★★ 
                Me.RECORD.DistView = CStr(dict.GetAttr(VIEW, strViewId))


                Return True
            End If
        End If
        Return False
    End Function
#End Region

#Region "Percer : [VFilter]-[SelectCondition]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' <summary>
    '''  [SelectCondition]タグブロックのパース 
    '''   ブロックから抽出条件を取得する。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    Private Function Parcer_SelectCondition(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1

        Dim arryColumns As String()
        '■■■■■■■■■■■■■■■■■■■■■■■■
        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        'If intBlockLineCount >= 2 Then
        If intBlockLineCount >= 3 Then
            ' カンマ区切りで分割して配列に格納する
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)

            '移送元　属性情報の取得
            '参照ビューＩＤ
            Dim strSelectConditionViewID = arryColumns(0).Trim
            '設定値
            Dim strSelectConditionValue = arryColumns(2).Trim
            '演算子
            Dim strSelectConditionOperator = arryColumns(3).Trim
            '参照テーブルのカラムＩＤ
            Dim strSelectConditionColumnID = arryColumns(10).Trim

            '属性名称を取得
            Dim key As String = strSelectConditionViewID & "_" & strSelectConditionColumnID
            Dim val As String
            Try
                'val = hashColumn(key)

                ' ★★★★★★★★★★★★★★★★ 
                'val = CStr(dict.GetAttr(key))
                'val = CStr(dict.GetAttr(strSelectConditionViewID, strSelectConditionColumnID))
                val = CStr(dict.GetAttr(COLUMN, strSelectConditionViewID, strSelectConditionColumnID))

                If val = Nothing Then
                    Return False
                End If
            Catch ex As Exception
                'foo = "-"
                Return False
            End Try

            Me.RECORD.SelectConditionAttr = val
            Me.RECORD.SelectConditionVal = strSelectConditionValue
            Me.RECORD.SelectConditionOpe = strSelectConditionOperator

            Return True

        End If
        Return False
    End Function
#End Region



#Region "Percer : [CFilter]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' <summary>
    '''  [CFilter]タグブロックのパース 
    '''   移送先・属性情報
    '''  </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    Private Function Parcer_CFilter(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1

        Dim arryColumns As String()
        '■■■■■■■■■■■■■■■■■■■■■■■■
        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        If intBlockLineCount >= 2 Then
            ' カンマ区割
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)


            '移送先ビューＩＤ
            Dim strDistViewId = arryColumns(0).Trim
            '属性項目
            Dim strDistColId = arryColumns(1).Trim

            '属性名称を取得
            Dim val As String
            Try
                Dim key As String = strDistViewId & "_" & strDistColId
                'val = hashColumn(key)

                ' ★★★★★★★★★★★★★★★★ 
                'val = CStr(dict.GetAttr(strSelectConditionViewID, strSelectConditionColumnID))
                val = CStr(dict.GetAttr(COLUMN, strDistViewId, strDistColId))

                If val = Nothing Then
                    Return False
                End If
            Catch ex As Exception
                'foo = "-"
                Return False
            End Try


            Me.RECORD.DistViewID = strDistViewId
            'Me.RECORD.DistView = hashViewTable(strDistViewId)
            Me.RECORD.DistView = CStr(dict.GetAttr(VIEW, strDistViewId))


            ' ★★★★★★★★★★★★★★★★ 
            'val = CStr(dict.GetAttr())

            Me.RECORD.DistColId = strDistColId
            'Me.RECORD.DistColName = Me.hashColumn(strDistColId)
            Me.RECORD.DistColName = CStr(dict.GetAttr(COLUMN, strDistViewId, strDistColId))

            Me.RECORD.DistColLength = CStr(dict.GetAttr(COLUMN_LENGTH, strDistViewId, strDistColId))


            Return True

        End If
        Return False
    End Function
#End Region




#Region "Percer : [CFilter]-[CFValue]  ■■■■■■■■■■■■■■■■■■■■■■■■"
    ''' <summary>
    '''  [CFValue]タグブロックのパース 
    '''   移送先・属性情報
    '''  </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    Private Function Parcer_CFValue(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As Boolean
        If (strLine = Nothing) Then
            Return False
        End If

        '全wtjファイルを通じての通番
        intTotalLineCount += 1

        Dim arryColumns As String()
        '■■■■■■■■■■■■■■■■■■■■■■■■
        'ブロック内行カウンターが２行目以上　※１行目はカラムタイトル
        If intBlockLineCount >= 2 Then
            ' カンマ区割
            arryColumns = Split(strLine, Chr(9), , CompareMethod.Text)

            ' 移送元・属性情報の取得
            ' 移送元・ビューID
            Dim orgViewID = arryColumns(0).Trim()
            ' 移送元・移送値
            'Dim strFValueValue = arryColumns(2).Trim()
            Dim orgValue = arryColumns(2).Trim()
            ' 関数タイプ
            'Dim strFValueSFType = arryColumns(4).Trim()
            Dim FunctionType = arryColumns(4).Trim()
            ' 実値型
            Dim valueRealValueType = arryColumns(5).Trim()

            ' 移送元・カラムID
            'Dim strFValuelikColID = arryColumns(9).Trim()
            Dim orgColumID = arryColumns(9).Trim()

            'Dim strFValueID = arryColumns(11).Trim()
            Dim orgFValueID = arryColumns(11).Trim()

            ' ルートフラグ （直接移送）
            Dim fValueIsRoot = arryColumns(10).Trim()

            ' パラメータ （直接移送）
            Dim fValueChildIDs = arryColumns(13).Trim()

            ' 二項比較子
            Dim fValueValueType = arryColumns(1).Trim()
            Dim fValueSetValueType = arryColumns(3).Trim()
            Dim fValueObjType = arryColumns(6).Trim()


            'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


            '移送先ビューＩＤ
            'Dim strDistViewId = arryColumns(0).Trim
            ''属性項目
            'Dim strDistColId = arryColumns(1).Trim

            '移送元・属性情報
            Try
                Dim functionNum As Integer
                Try
                    functionNum = Integer.Parse(FunctionType)
                Catch ex As Exception
                    functionNum = 0
                End Try




                '移送元・ビューID
                Me.RECORD.OrgViewID = orgViewID

                '移送元・ビューテーブル名称
                Me.RECORD.OrgView = CStr(dict.GetAttr(VIEW, orgViewID))

                '移送元・カラム名称
                Me.RECORD.OrgColId = CStr(orgColumID)

                '移送元・カラム長
                Me.RECORD.OrgColLength = CStr(dict.GetAttr(COLUMN_LENGTH, orgViewID, orgColumID))

                '移送元・カラム名称
                Me.RECORD.OrgColName = CStr(dict.GetAttr(COLUMN, orgViewID, orgColumID))

                Me.RECORD.ValueType = CStr(valueRealValueType)

                Me.RECORD.FunctionType = CStr(FunctionType)

                '直送フラグ
                ' IsRoot=1 かつ ChildsIds=0 の場合、"直接移送" とみなす
                If fValueIsRoot = "1" And fValueChildIDs = "0" Then
                    Me.RECORD.DirectFlg = "1"
                Else
                    Me.RECORD.DirectFlg = ""
                End If


                Dim functionName As String

                If orgViewID = "0" And orgColumID = "0" Then
                    If functionNum > 0 Then
                        Me.RECORD.OrgColId = "0"
                        Me.RECORD.OrgColLength = "0"
                        functionName = dict.GetAttr(FUNCT, FunctionType)
                        If functionName.Length > 0 Then
                            Me.RECORD.OrgColName = "■Function[" & functionName & "]"
                        Else
                            '関数がDictionaryに登録されていない場合 , 関数IDを出力
                            Me.RECORD.OrgColName = "■Function[" & FunctionType & "]"
                        End If
                    End If
                End If


                Return True
            Catch ex As Exception
                'foo = "-"
                Return False
            End Try


            Return True

        End If
        Return False
    End Function
#End Region




    '   	/**
    ' * 配列中から、Key に一致するIndex を返す。
    ' *
    ' * @param keyList
    ' *            探査対象配列
    ' * @param key
    ' *            探査キーワード
    ' */
    'Private Static int getKeysindex(String[] keyList, String key) {
    '	For (int i = 0; i < keyList.length; i++) {
    '		If (keyList[i].matches(key)) {
    '			Return i;
    '		}
    '	}
    '	// マッチした項目が存在しない。
    '	Return -1;
    '}


#Region "Util"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  配列中から、Key に一致するIndex を返す。
    '''  </summary>
    ''' <param name="key">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Function getKeysindex(keyList As String(), key As String)

        If (key = Nothing) Then
            Return -1
        End If
        key = key.Trim

        Dim foo As String
        For i As Integer = 0 To keyList.Length - 1
            foo = keyList(i).Trim
            If String.Equals(foo, key) Then
                'マッチしたインデックスを返す
                Return i
            End If
        Next

        '全て不一致
        Return -1
    End Function


    ''' -----------------------------------------------------------------------------------
    Private Sub CONSOLEWRITE(foo As String, var As String)
        Console.WriteLine(foo & " : " & var)
    End Sub


#End Region



End Class
