﻿'----------------------------------------------------
'wtjの構文解析クラス
' 解析対象のファイルパスを受けて、構文解析を行い、結果を出力
'----------------------------------------------------

Imports System.Text.RegularExpressions


Public Class SyntacticAnalysis

    Private FilePath As String



    ' タグ・キーワード  Enum
    Private Enum Status
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iSquareBracket
        iNone
    End Enum

    'タグ・キーワード  ストリングパターン
    Private regPatternView As String = "^\[View\]"
    Private regPatternColumn As String = "^\[Column\]"
    Private regPatternVFilter As String = "^\[VFilter\]"
    Private regPatternCFilter As String = "^\[CFilter\]"
    Private regPatternCFValue As String = "^\[CFValue\]"
    Private regPatternSelectCondition As String = "^\[SelectCondition\]"
    Private regPatternDViewSelectCondition As String = "^\[DViewSelectCondition\]"
    Private regPatternDeleteSelectContdition As String = "^\[DeleteSelectContdition\]"
    Private regPatternRepository As String = "^\[Repository\]"
    Private regPatternProcess As String = "^\[Process\]"
    Private regPatternViewInfo As String = "^\[ViewInfo\]"
    Private regPatternLookupViewInfo As String = "^\[LookupViewInfo\]"
    Private regPatternSquareBracket As String = "^\["
    '----------------------------------------------------------------------------------
    Private rxView = New Regex(regPatternView, RegexOptions.Compiled)
    Private rxColumn = New Regex(regPatternColumn, RegexOptions.Compiled)
    Private rxVFilter = New Regex(regPatternVFilter, RegexOptions.Compiled)
    Private rxCFilter = New Regex(regPatternCFilter, RegexOptions.Compiled)
    Private rxCFValue = New Regex(regPatternCFValue, RegexOptions.Compiled)
    Private rxSelectCondition = New Regex(regPatternSelectCondition, RegexOptions.Compiled)
    Private rxDViewSelectCondition = New Regex(regPatternDViewSelectCondition, RegexOptions.Compiled)
    Private rxDeleteSelectContdition = New Regex(regPatternDeleteSelectContdition, RegexOptions.Compiled)
    Private rxRepository = New Regex(regPatternRepository, RegexOptions.Compiled)
    Private rxProcess = New Regex(regPatternProcess, RegexOptions.Compiled)
    Private rxViewInfo = New Regex(regPatternViewInfo, RegexOptions.Compiled)
    Private rxLookupViewInfo = New Regex(regPatternLookupViewInfo, RegexOptions.Compiled)
    Private rxSquareBracket = New Regex(regPatternSquareBracket, RegexOptions.Compiled)


    '[View」テーブル定義名称を格納する。※IDをインデックスとしたストリング名称を格納する。
    Private hashViewTable = New Hashtable()
    '[Column」テーブル属性名称を格納する。※IDをインデックスとしたテーブルの属性名称を格納する。
    Private hashColumn = New Hashtable()
    Private hashColumnLength = New Hashtable()



    'TagBlock
    Private intTAG_BLOCK_ID As String
    Private Function GetTAG_BLOCK_ID() As String
        Return intTAG_BLOCK_ID
    End Function
    Private Function SetTAG_BLOCK_ID(ByVal val As String)
        intTAG_BLOCK_ID = val
    End Function



    'ViewID
    Private intVIEW_ID As String
    Private Function GetVIEW_ID() As String
        Return intVIEW_ID
    End Function
    Private Function SetVIEW_ID(ByVal val As String)
        intVIEW_ID = val
    End Function

    ''' -----------------------------------------------------------------------------------
    ''' コンストラクタ
    ''' -----------------------------------------------------------------------------------
    Public Sub New()
    End Sub

    Public Sub New(ByVal strPath As String)
        If strPath Is Nothing Then
            Throw New ArgumentNullException(NameOf(strPath))
        End If
    End Sub

    ''' -----------------------------------------------------------------------------------
    ''' 初期化
    ''' -----------------------------------------------------------------------------------
    Public Sub Initialize(ByVal strPath As String)
    End Sub



    ' wtj→text へ構文変換
    'Public Sub Parce(ByVal strPath As String)
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="strPath"></param>
    Public Sub Conversion(ByVal strPath As String)

        '1.ファイル存在チェック
        If IO.File.Exists(strPath) = False Then
            Exit Sub
        End If

        '2.ファイル読込み
        Dim cReader As IO.StreamReader
        '読込ストリーマ
        cReader = New IO.StreamReader(strPath, System.Text.Encoding.Default)

        '書込ストリーマ
        'Dim cWriter As IO.StreamWriter
        'cWriter = New IO.StreamWriter("F:\test.txt", True)
        Using cWriter = New IO.StreamWriter(New IO.FileStream("F:\test.txt", IO.FileMode.Create))


            'ファイル読込み
            Dim intBlockID As UInteger = 0   'タグＩＤ保持用
            Dim intBlockLineCount As UInteger = 0   'タグブロック内行カウンター

            Dim strOutLine As String
            Dim strLine As String
            Dim intStatus As String

            Dim intRowCount As Integer = 0

            While (cReader.Peek() >= 0)
                intRowCount += 1

                '１行読込み
                strLine = cReader.ReadLine

                'タグキーワードに紐ずくＩＤを取得する。
                intStatus = getStatus(strLine)
                'Console.WriteLine("0>intStatus " & intStatus & ":" & strLine)

                Console.WriteLine("00>GetTAG_BLOCK_ID :" & GetTAG_BLOCK_ID())




                '読込行にタグが検出された場合ブロック内カウンターを初期化する。
                'If (intBlockLineCount > 0 & intStatus <> Status.iNone) Then
                If (intStatus <> Status.iNone) Then
                    '新しいタグ検知
                    intBlockLineCount = 0
                    intBlockID = intStatus
                    'Console.WriteLine("1>intBlockLineCount=0 ")
                    Console.WriteLine(intRowCount & "  1>" & intBlockID & "-" & intBlockLineCount)
                Else
                    intBlockLineCount += 1
                    'Console.WriteLine("2>intStatus " & intStatus & "  intBlockLineCount=" & intBlockLineCount)
                    Console.WriteLine(intRowCount & "  2>" & intBlockID & "-" & intBlockLineCount)
                End If

                '構文解析　※各タグ毎の構文解析を行う
                strOutLine = Parcer(intBlockID, intBlockLineCount, strLine)

                'ファイル出力
                'cWriter.WriteLineAsync(strLine)
                cWriter.WriteLine(strLine)

            End While
            cReader.Close()

            cWriter.Flush()
        End Using
        'cWriter.FlushAsync()
        'cWriter.Close()

        Console.WriteLine("  >" & hashColumn.ToString())
        ' キーの列挙
        For Each key As String In hashColumn.Keys

            Dim val As String = hashColumn(key)
            Console.WriteLine(key & "-" & val)
        Next


        'Dim fileReader As System.IO.StreamReader
        'fileReader =
        'My.Computer.FileSystem.OpenTextFileReader(strPath)
        'Dim stringReader As String
        'stringReader = fileReader.ReadLine()
        MsgBox("The first line of the file is ")


        '2.タグチェック　[View],[Column],[VFilter],[CFilter]...


        '3.タグブロック内処理
        '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる

    End Sub




    '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる



#Region "タグキーワードのパターンマッチ"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function getStatus(ByVal strLine As String) As UInteger

        If (strLine = Nothing) Then
            Return Status.iNone
        End If

        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        If rxView.IsMatch(strLine) Then
            Console.WriteLine("0■    " & strLine)
            SetTAG_BLOCK_ID(Status.iView)
            Return Status.iView
        ElseIf rxColumn.IsMatch(strLine) Then
            Console.WriteLine("1■    " & strLine)
            SetTAG_BLOCK_ID(Status.iColumn)
            Return Status.iColumn
        ElseIf rxVFilter.IsMatch(strLine) Then
            Console.WriteLine("2■    " & strLine)
            SetTAG_BLOCK_ID(Status.iVFilter)
            Return Status.iVFilter
        ElseIf rxCFilter.IsMatch(strLine) Then
            Console.WriteLine("3■    " & strLine)
            SetTAG_BLOCK_ID(Status.iCFilter)
            Return Status.iCFilter
        ElseIf rxCFValue.IsMatch(strLine) Then
            Console.WriteLine("4■    " & strLine)
            SetTAG_BLOCK_ID(Status.iCFValue)
            Return Status.iCFValue
        ElseIf rxSelectCondition.IsMatch(strLine) Then
            Console.WriteLine("5■    " & strLine)
            SetTAG_BLOCK_ID(Status.iSelectCondition)
            Return Status.iSelectCondition
        ElseIf rxDViewSelectCondition.IsMatch(strLine) Then
            Console.WriteLine("6■    " & strLine)
            SetTAG_BLOCK_ID(Status.iDViewSelectCondition)
            Return Status.iDViewSelectCondition
        ElseIf rxDeleteSelectContdition.IsMatch(strLine) Then
            Console.WriteLine("7■    " & strLine)
            SetTAG_BLOCK_ID(Status.iDeleteSelectContdition)
            Return Status.iDeleteSelectContdition
        ElseIf rxRepository.IsMatch(strLine) Then
            Console.WriteLine("8■    " & strLine)
            SetTAG_BLOCK_ID(Status.iRepository)
            Return Status.iRepository
        ElseIf rxProcess.IsMatch(strLine) Then
            Console.WriteLine("9■    " & strLine)
            SetTAG_BLOCK_ID(Status.iProcess)
            Return Status.iProcess
        ElseIf rxViewInfo.IsMatch(strLine) Then
            Console.WriteLine("10■    " & strLine)
            SetTAG_BLOCK_ID(Status.iViewInfo)
            Return Status.iViewInfo
        ElseIf rxLookupViewInfo.IsMatch(strLine) Then
            Console.WriteLine("12■    " & strLine)
            SetTAG_BLOCK_ID(Status.iLookupViewInfo)
            Return Status.iLookupViewInfo

        ElseIf rxSquareBracket.IsMatch(strLine) Then
            Console.WriteLine("13■    " & strLine)
            SetTAG_BLOCK_ID(Status.iSquareBracket)
            Return Status.iSquareBracket
        Else
            Return Status.iNone
        End If


    End Function
#End Region


    '構文解析　※各タグ毎の構文解析を行う
    'strOutLine = parcer(intBlockID, intBlockLineCount, strLine)



#Region "タグキーワードのパターンマッチ"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  "タグキーワード"をパターンマッチ し、キーワードに対応したＩＤを返す    </summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     タグキーワードに対応したＩＤ     </returns>
    ''' -----------------------------------------------------------------------------------
    Private Function Parcer(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String) As String

        If (strLine = Nothing) Then
            Return Nothing
        End If

        'Select Case intBlockID
        '現在のタグのブロックＩＤによって、構文の処理を変える
        Select Case GetTAG_BLOCK_ID()
            Case Status.iView
                ParcerView(intBlockID, intBlockLineCount, strLine)
                Return Nothing
            Case Status.iColumn
                '[View]ブロックの次には必ず[Column]ブロックが定義される。
                ParcerColum(intBlockID, intBlockLineCount, strLine)
                Return Nothing
            Case Status.iVFilter
                ParcerVFilter(intBlockID, intBlockLineCount, strLine)
                Return Nothing

            Case Status.iCFilter
                Return Nothing
            Case Status.iCFValue
                Return Nothing
            Case Status.iSelectCondition
                Return Nothing
            Case Status.iDViewSelectCondition
                Return Nothing
            Case Status.iDeleteSelectContdition
                Return Nothing
            Case Status.iRepository
                Return Nothing
            Case Status.iProcess
                Return Nothing
            Case Status.iViewInfo
                Return Nothing
            Case Status.iLookupViewInfo
                Return Nothing
            Case Status.iNone
                Return Nothing

        End Select


        'Return Status.iNone


        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        '        If rxView.IsMatch(strLine) Then
        '        Console.WriteLine("0■    " & strLine)
        '        Return Status.iView
        '        ElseIf rxColumn.IsMatch(strLine) Then
        '        Return Status.iLookupViewInfo
        '        Else
        '        Return Status.iNone
        '        End If

    End Function
#End Region




#Region "Percer : [View]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  [View]タグブロックのパース 
    '''  View ブロックからＩ／Ｏテーブル名称を取得し、Viewハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub ParcerView(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If

        Dim columnsList As String()
        'If intBlockLineCount = 3 Then
        If intBlockLineCount = 2 Then
            ' カンマ区切りで分割して配列に格納する
            columnsList = Split(strLine, Chr(9), , CompareMethod.Text)
            'ViewハッシュにテーブルＩＤとテーブル名称を登録
            If columnsList.Length > 7 Then
                Dim viewID As String = columnsList(7)    'View ID
                Dim viewName As String = columnsList(8)  'View 名称
                SetVIEW_ID(viewID)



                hashViewTable.Add(GetVIEW_ID(), viewName)

                MsgBox(">>>VIEW_ID" & GetVIEW_ID())
            End If
        End If
    End Sub
#End Region



#Region "Percer : [Colum]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  [View]タグブロックのパース 
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub ParcerColum(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        'If (GetVIEW_ID() <> Status.iColumn) Then
        'Return
        If (strLine = Nothing) Then
            Return
        End If

        Dim columnsList As String()
        'If intBlockLineCount = 3 Then
        If intBlockLineCount >= 2 Then
            ' カンマ区切りで分割して配列に格納する
            columnsList = Split(strLine, Chr(9), , CompareMethod.Text)

            'ViewハッシュにテーブルＩＤとテーブル名称を登録
            If columnsList.Length > 6 Then
                Dim columnName As String = columnsList(5)   '属性名称
                Dim columnLength As String = columnsList(6) '属性長
                Dim columnID As String = columnsList(10)    '属性ID

                Dim key As String = GetVIEW_ID() & "_" & columnID

                '属性名称、属性長をハッシュにストア
                hashColumn.Add(key, columnName)
                hashColumnLength.Add(key, columnLength)
            End If
        End If
    End Sub
#End Region




#Region "Percer : [VFilter]"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''  [View]タグブロックのパース 
    '''  Colum ブロックから属性名称を取得し、Columハッシュにストアする。
    '''  タグ以降２行目がパース対象</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' -----------------------------------------------------------------------------------
    Private Sub ParcerVFilter(intBlockID As UInteger, intBlockLineCount As UInteger, ByVal strLine As String)

        If (strLine = Nothing) Then
            Return
        End If
        Dim columnsList As String
        columnsList = "aaaa"

    End Sub
#End Region









End Class
