﻿

' -----------------------------------------------------------------------------------------
' 《出力フォーマット (20130604)》
'  1 シーケンス番号	　数値文字列	15		許可	※出力シーケンス(20130604 新規追加)
'  2 タイムスタンプ	　数値文字列	15		許可	※20130418 新規追加
'  3 WTJファイル名	　　　　　　文字	128		許可	WTJファイル名称
'  4 ビューフィルタ種別	　　数値	2	0	許可	0：標準, 1：結合, 2：統合, 4：, 5：参照
'  5 ビューフィルタ種別名称	文字	8		許可
'  6 ビューフィルタ名称	　　文字	99		許可	ViewFilter名称
'  7 移送先ビューID	　数値文字列	3	0	許可	移送先・ビューID
'  8 移送先ビューテーブル名称	文字	99		許可
'  9 移送先カラムID	　数値文字列	4	0	許可	移送先・カラムID
' 10 移送先カラム長	　数値文字列	4	0	許可
' 11 移送先カラム名称	　　　　文字	99		許可	移送先・カラム名称
' 12 移送元ビューID	　数値文字列	3	0	許可	移送元・ビューID
' 13 移送元ビューテーブル名称	文字	99		許可
' 14 移送元カラムID	　数値文字列	5	0	許可	移送元・カラムID
' 15 移送元カラム長	　数値文字列	4	0	許可
' 16 移送元カラム名称	　　　　文字	256		許可	移送元・カラム名称
' 17 移送値型	　　　　　数値文字列	3	0	許可	Valタイプフラグ
' 18 移送値	　　　　　　　　文字	256		許可	実値(Value)
' 19 関数タイプ	　　　数値文字列	4	0	許可	関数ID
' 20 直接移送フラグ	　数値文字列	1	0	許可	１：直接移送
' 21 抽出条件（値）	　　　　文字	32		許可
' 22 抽出条件（演算子）	　　文字	8		許可
' 23 抽出条件（項目）	　　　　文字	64		許可
' -----------------------------------------------------------------------------------------



Public Class StructRecord

    Private ENUMTAG = New EnumTag()

    'ビューフィルタ種別名称・ディクショナリー
    Private dicVIEW_FILTER_NAME = New Dictionary(Of String, String)

    'オペレータ演算子・ディクショナリー
    Private DIC_OPERATOR_NAME = New Dictionary(Of String, String)


    'dicVIEW_FILTER_NAME.Add("1", "Hoge")

    'Console.WriteLine(dic(New MyKey(1, 1)))




    ' タイトル行 _
    Public Const COL_TITLE As String = "SeqNo," _
            & "タイムスタンプ," _
            & "格納フォルダ（業務名）," _
            & "WTJファイル名," _
            & "ビューフィルタ種別," _
            & "ビューフィルタ種別名称," _
            & "ビューフィルタ名称," _
            & "移送先ビューID," _
            & "移送先ビューテーブル名称," _
            & "移送先カラムID," _
            & "移送先カラム長," _
            & "移送先カラム名称," _
            & "移送元ビューID," _
            & "移送元ビューテーブル名称," _
            & "移送元カラムID," _
            & "移送元カラム長," _
            & "移送元カラム名称," _
            & "移送値型," _
            & "移送値," _
            & "関数タイプ," _
            & "直送フラグ," _
            & "抽出条件（条件値）," _
            & "抽出条件（比較演算子）," _
            & "抽出条件（項目）," _
            & "WorkDir," _
            & "処理（0:前／1:後),"

    Private _seqNo As String                ' "SeqNo,"
    Private _timeStamp As String            ' "タイムスタンプ," _
    Private _parentDir As String            ' "格納フォルダ（業務名）,"
    Private _fileNameBody As String         ' "WTJファイル名,"
    Private _vFilterKind As String          ' "ビューフィルタ種別,"
    Private _vFilterKindName As String      ' "ビューフィルタ種別名称,"
    Private _vFilterName As String          ' "ビューフィルタ名称,"

    Private _distViewID As String          ' "移送先ビューID," 
    Private _distView As String            ' "移送先ビューテーブル名称," _
    Private _distColId As String            ' "移送先カラムID," _
    Private _distColLength As String        ' "移送先カラム長," _
    Private _distColName As String          ' "移送先カラム名称," _

    Private _orgViewID As String           ' "移送元ビューID," 
    Private _orgView As String             ' "移送元ビューテーブル名称," _
    Private _orgColId As String             ' "移送元カラムID," _
    Private _orgColLength As String         ' "移送元カラム長," _
    Private _orgColName As String           ' "移送元カラム名称," _

    Private _valueType As String            ' "移送値型," _
    Private _value As String                ' "移送値," _
    Private _functionType As String         ' "関数タイプ," _
    Private _directFlg As String            ' "直送フラグ," _

    Private _selectConditionVal As String   ' "抽出条件（条件値）," _	
    Private _selectConditionOpe As String   ' "抽出条件（比較演算子）,"
    Private _selectConditionAttr As String  ' "抽出条件（項目）," _
    Private _workDir As String              ' "WorkDir," _
    Private _prcessing As String            ' "処理（0:前／1:後),"


    Public Enum Tag
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iSquareBracket
        iNone
    End Enum


    Sub New()
        Me.dicVIEW_FILTER_NAME.add("0", "標準")
        Me.dicVIEW_FILTER_NAME.add("1", "結合")
        Me.dicVIEW_FILTER_NAME.add("2", "統合")
        Me.dicVIEW_FILTER_NAME.add("3", "集計")
        Me.dicVIEW_FILTER_NAME.add("4", "分割")
        Me.dicVIEW_FILTER_NAME.add("5", "参照")
        Me.dicVIEW_FILTER_NAME.add("6", "縦展開")
        Me.dicVIEW_FILTER_NAME.add("7", "更新")

        ' 1:≠, 2:＜, 3:＞, 4:≦, 5:≧, 6:中間一致, 7:前方一致, 8:後方一致
        Me.DIC_OPERATOR_NAME.add("0", "")
        Me.DIC_OPERATOR_NAME.add("1", "≠")
        Me.DIC_OPERATOR_NAME.add("2", "＜")
        Me.DIC_OPERATOR_NAME.add("3", "＞")
        Me.DIC_OPERATOR_NAME.add("4", "≦")
        Me.DIC_OPERATOR_NAME.add("5", "≧")
        Me.DIC_OPERATOR_NAME.add("6", "中間一致")
        Me.DIC_OPERATOR_NAME.add("7", "前方一致")
        Me.DIC_OPERATOR_NAME.add("8", "後方一致")
    End Sub



    Public Property SeqNo As String
        Get
            Return _seqNo
        End Get
        Set(value As String)
            _seqNo = value
        End Set
    End Property

    Public Property TimeStamp As String
        Get
            Return _timeStamp
        End Get
        Set(value As String)
            _timeStamp = value
        End Set
    End Property

    Public Property ParentDir As String
        Get
            Return _parentDir
        End Get
        Set(value As String)
            _parentDir = value
        End Set
    End Property

    Public Property FileNameBody As String
        Get
            Return _fileNameBody
        End Get
        Set(value As String)
            _fileNameBody = value
        End Set
    End Property

    Public Property VFilterKind As String
        Get
            Return _vFilterKind
        End Get
        Set(value As String)
            _vFilterKind = value
        End Set
    End Property

    Public Property VFilterKindName As String
        Get
            Return _vFilterKindName
        End Get
        Set(value As String)
            _vFilterKindName = value
        End Set
    End Property

    Public Property VFilterName As String
        Get
            Return _vFilterName
        End Get
        Set(value As String)
            _vFilterName = value
        End Set
    End Property

    Public Property DistViewID As String
        Get
            Return _distViewID
        End Get
        Set(value As String)
            _distViewID = value
        End Set
    End Property

    Public Property DistView As String
        Get
            Return _distView
        End Get
        Set(value As String)
            _distView = value
        End Set
    End Property

    Public Property DistColId As String
        Get
            Return _distColId
        End Get
        Set(value As String)
            _distColId = value
        End Set
    End Property

    Public Property DistColLength As String
        Get
            Return _distColLength
        End Get
        Set(value As String)
            _distColLength = value
        End Set
    End Property

    Public Property DistColName As String
        Get
            Return _distColName
        End Get
        Set(value As String)
            _distColName = value
        End Set
    End Property

    Public Property OrgViewID As String
        Get
            Return _orgViewID
        End Get
        Set(value As String)
            _orgViewID = value
        End Set
    End Property

    Public Property OrgView As String
        Get
            Return _orgView
        End Get
        Set(value As String)
            _orgView = value
        End Set
    End Property

    Public Property OrgColId As String
        Get
            Return _orgColId
        End Get
        Set(value As String)
            _orgColId = value
        End Set
    End Property

    Public Property OrgColLength As String
        Get
            Return _orgColLength
        End Get
        Set(value As String)
            _orgColLength = value
        End Set
    End Property

    Public Property OrgColName As String
        Get
            Return _orgColName
        End Get
        Set(value As String)
            _orgColName = value
        End Set
    End Property

    Public Property ValueType As String
        Get
            Return _valueType
        End Get
        Set(value As String)
            _valueType = value
        End Set
    End Property

    Public Property Value As String
        Get
            Return _value
        End Get
        Set(value As String)
            _value = value
        End Set
    End Property

    Public Property FunctionType As String
        Get
            Return _functionType
        End Get
        Set(value As String)
            _functionType = value
        End Set
    End Property

    Public Property DirectFlg As String
        Get
            Return _directFlg
        End Get
        Set(value As String)
            _directFlg = value
        End Set
    End Property

    Public Property SelectConditionVal As String
        Get
            Return _selectConditionVal
        End Get
        Set(value As String)
            _selectConditionVal = value
        End Set
    End Property

    Public Property SelectConditionOpe As String
        Get
            Return _selectConditionOpe
        End Get
        Set(value As String)
            _selectConditionOpe = value
        End Set
    End Property

    Public Property SelectConditionAttr As String
        Get
            Return _selectConditionAttr
        End Get
        Set(value As String)
            _selectConditionAttr = value
        End Set
    End Property

    Public Property WorkDir As String
        Get
            Return _workDir
        End Get
        Set(value As String)
            _workDir = value
        End Set
    End Property

    Public Property Prcessing As String
        Get
            Return _prcessing
        End Get
        Set(value As String)
            _prcessing = value
        End Set
    End Property



    'Public Function Println(tagStatus As UInteger) As String
    Public Function getLine(tagStatus As UInteger) As String

        Dim strOutLine As String = ""

        '現在のタグのブロックＩＤによって、構文の処理を変える
        Select Case tagStatus
            'Case Status.iView
            '    ParcerView(intBlockID, intBlockLineCount, strLine)
            '    Return Nothing
            'Case Status.iColumn
            '    '[View]ブロックの次には必ず[Column]ブロックが定義される。
            '    ParcerColum(intBlockID, intBlockLineCount, strLine)
            '    Return Nothing

            'Case Me.Tag.iVFilter

            Case Tag.iVFilter
                'ビューフィルタ1件の情報
                '[VFilter]ブロック  ビューフィルタ定義

                'TODOーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー
                strOutLine = Me.SeqNo _
                            & "," _
                            & Me.TimeStamp _
                            & "," _
                            & Me._parentDir _
                            & "," _
                            & Me.FileNameBody _
                            & "," _
                            & Me.VFilterName _
                            & "," _
                            & VFilterKindName _
                            & "," _
                            & VFilterName _
                            & "," _
                            & Me.DistViewID _
                            & "," _
                            & Me.DistView _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & Me.WorkDir _
                            & "," _
                            & "cDicision" _
                            & "," _
                            & "CMDLINE→" + "cCommandLine"

                Return strOutLine


            Case Tag.iViewInfo
                '[ViewInfo]ブロック  ビューフィルタ定義
                Dim filterKindName As String
                Try
                    filterKindName = Me.dicVIEW_FILTER_NAME(Me.VFilterKind)
                Catch ex As Exception
                    filterKindName = "-"
                End Try
                strOutLine = Me.SeqNo _
                            & "," _
                            & Me.TimeStamp _
                            & "," _
                            & Me._parentDir _
                            & "," _
                            & Me.FileNameBody _
                            & "," _
                            & Me.VFilterKind _
                            & "," _
                            & filterKindName _
                            & "," _
                            & Me.VFilterName _
                            & "," _
                            & Me.DistViewID _
                            & "," _
                            & Me.DistView _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & Me.OrgViewID _
                            & "," _
                            & Me.OrgView _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & Me.WorkDir _
                            & "," _
                            & "," _
                            & ""
                Return strOutLine

                'Case Status.iCFilter
                '    Return Nothing
                'Case Status.iCFValue
                '    Return Nothing
                '    Return Nothing
                'Case Status.iDViewSelectCondition

            Case Tag.iSelectCondition
                '[SelectCondition]ブロック  ※抽出条件
                Dim ope As String
                Try
                    ' 1:≠, 2:＜, 3:＞, 4:≦, 5:≧, 6:中間一致, 7:前方一致, 8:後方一致
                    'ope = Me.DIC_OPERATOR_NAME(Me.SelectConditionVal)
                    ope = Me.DIC_OPERATOR_NAME(Me.SelectConditionOpe)
                Catch ex As Exception
                    ope = "-"
                End Try
                strOutLine = Me.SeqNo _
                            & "," _
                            & Me.TimeStamp _
                            & "," _
                            & Me._parentDir _
                            & "," _
                            & Me.FileNameBody _
                            & "," _
                            & Me.VFilterKind _
                            & "," _
                            & "抽出条件" _
                            & "," _
                            & Me.VFilterName _
                            & "," _
                            & Me.DistViewID _
                            & "," _
                            & Me.DistView _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & Me.OrgViewID _
                            & "," _
                            & Me.OrgView _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & "," _
                            & Me.SelectConditionVal _
                            & "," _
                            & ope _
                            & "," _
                            & Me.SelectConditionAttr _
                            & "," _
                            & Me.WorkDir _
                            & "," _
                            & "," _
                            & ""
                Return strOutLine
            'Case Status.iDeleteSelectContdition
            '    Return Nothing
            'Case Status.iRepository
            '    Return Nothing
            'Case Status.iProcess
            '    Return Nothing
            'Case Status.iLookupViewInfo
            '    Return Nothing
            Case Tag.iNone
                Return Nothing

        End Select




        Return Nothing

    End Function



    Public Sub checkPrint(iStatus As UInteger)

        Dim line As String = Me.getLine(iStatus)
        Console.WriteLine("iStatus>>> " & iStatus & "---" & line)

    End Sub


End Class
