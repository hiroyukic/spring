﻿'----------------------------------------------------
'wtjの構文解析クラス
' 解析対象のファイルパスを受けて、構文解析を行い、結果を出力
'----------------------------------------------------

Imports System.Text.RegularExpressions


Public Class SyntacticAnalysis

    Private FilePath As String



    Private Enum Status
        iView
        iColumn
        iVFilter
        iCFilter
        iCFValue
        iSelectCondition
        iDViewSelectCondition
        iDeleteSelectContdition
        iRepository
        iProcess
        iViewInfo
        iLookupViewInfo
        iNone
    End Enum


    'Dim regPatternColumn As String = "^\\[Column\\]"
    'Dim regPatternColumn As String = "\[Column\]"







    ''' -----------------------------------------------------------------------------------
    ''' コンストラクタ
    ''' -----------------------------------------------------------------------------------
    Public Sub New()
    End Sub

    Public Sub New(ByVal strPath As String)
        If strPath Is Nothing Then
            Throw New ArgumentNullException(NameOf(strPath))
        End If
    End Sub

    ''' -----------------------------------------------------------------------------------
    ''' 初期化
    ''' -----------------------------------------------------------------------------------
    Public Sub Initialize(ByVal strPath As String)
    End Sub



    ' wtj→text へ構文変換
    'Public Sub Parce(ByVal strPath As String)
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="strPath"></param>
    Public Sub Conversion(ByVal strPath As String)


        '1.ファイル存在チェック
        If IO.File.Exists(strPath) = False Then
            'fileが見つからない。
            Exit Sub
        End If


        '2.ファイル読込み
        Dim strLine As String
        Dim cReader As IO.StreamReader
        '読込ストリーマ
        cReader = New IO.StreamReader(strPath, System.Text.Encoding.Default)

        'ファイル読込み
        'strLine = cReader.ReadLine()
        Dim intStatus As String
        While (cReader.Peek() >= 0)
            '１行読込み
            strLine = cReader.ReadLine
            Console.WriteLine(strLine)

            intStatus = getStatus(strLine)
            Console.WriteLine("intStatus " & intStatus)
        End While


        cReader.Close()


        Dim fileReader As System.IO.StreamReader
        fileReader =
        My.Computer.FileSystem.OpenTextFileReader(strPath)
        Dim stringReader As String
        stringReader = fileReader.ReadLine()
        'MsgBox("The first line of the file is " & stringReader)






        '2.タグチェック　[View],[Column],[VFilter],[CFilter]...




        '3.タグブロック内処理
        '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる




    End Sub


    'Assemble


    '  ※ブロック内のセンテンスをパースし、出力構文を組み立てる


    ''' <summary>
    ''' 
    ''' </summary>
    Private regPatternView As String = "^\[View\]"
    Private regPatternColumn As String = "^\[Column\]"
    Private regPatternVFilter As String = "^\[VFilter\]"
    Private regPatternCFilter As String = "^\[CFilter\]"
    Private regPatternCFValue As String = "^\[CFValue\]"
    Private regPatternSelectCondition As String = "^\[SelectCondition\]"
    Private regPatternDViewSelectCondition As String = "^\[DViewSelectCondition\]"
    Private regPatternDeleteSelectContdition As String = "^\[DeleteSelectContdition\]"
    Private regPatternRepository As String = "^\[Repository\]"
    Private regPatternProcess As String = "^\[Process\]"
    Private regPatternViewInfo As String = "^\[ViewInfo\]"
    Private regPatternLookupViewInfo As String = "^\[LookupViewInfo\]"

    Private rxView = New Regex(regPatternView, RegexOptions.Compiled)
    Private rxColumn = New Regex(regPatternColumn, RegexOptions.Compiled)
    Private rxVFilter = New Regex(regPatternVFilter, RegexOptions.Compiled)
    Private rxCFilter = New Regex(regPatternCFilter, RegexOptions.Compiled)
    Private rxCFValue = New Regex(regPatternCFValue, RegexOptions.Compiled)
    Private rxSelectCondition = New Regex(regPatternSelectCondition, RegexOptions.Compiled)
    Private rxDViewSelectCondition = New Regex(regPatternDViewSelectCondition, RegexOptions.Compiled)
    Private rxDeleteSelectContdition = New Regex(regPatternDeleteSelectContdition, RegexOptions.Compiled)
    Private rxRepository = New Regex(regPatternRepository, RegexOptions.Compiled)
    Private rxProcess = New Regex(regPatternProcess, RegexOptions.Compiled)
    Private rxViewInfo = New Regex(regPatternViewInfo, RegexOptions.Compiled)
    Private rxLookupViewInfo = New Regex(regPatternLookupViewInfo, RegexOptions.Compiled)



#Region "タグキーワードをパターンマッチ"
    ''' -----------------------------------------------------------------------------------
    ''' <summary>
    '''     文字列の左端から指定された文字数分の文字列を返します。</summary>
    ''' <param name="strLine">
    '''     取り出す元になる文字列。</param>
    ''' <returns>
    '''     左端から指定された文字数分の文字列。
    '''     文字数を超えた場合は、文字列全体が返されます。</returns>
    ''' -----------------------------------------------------------------------------------
    Private Function getStatus(ByVal strLine As String) As UInteger

        'Dim regPatternColumn = "^\\[Column\\]

        If (strLine = Nothing) Then
            Return Status.iNone
        End If


        'タグキーワードのパターンマッチ　※タグが存在した場合、タグIDを返す
        If rxView.IsMatch(strLine) Then
            Console.WriteLine("0■    " & strLine)
            Return Status.iView
        ElseIf rxColumn.IsMatch(strLine) Then
            Console.WriteLine("1■    " & strLine)
            Return Status.iColumn
        ElseIf rxVFilter.IsMatch(strLine) Then
            Console.WriteLine("2■    " & strLine)
            Return Status.iVFilter
        ElseIf rxCFilter.IsMatch(strLine) Then
            Console.WriteLine("3■    " & strLine)
            Return Status.iCFilter
        ElseIf rxCFValue.IsMatch(strLine) Then
            Console.WriteLine("4■    " & strLine)
            Return Status.iCFValue
        ElseIf rxSelectCondition.IsMatch(strLine) Then
            Console.WriteLine("5■    " & strLine)
            Return Status.iSelectCondition
        ElseIf rxDViewSelectCondition.IsMatch(strLine) Then
            Console.WriteLine("6■    " & strLine)
            Return Status.iDViewSelectCondition
        ElseIf rxDeleteSelectContdition.IsMatch(strLine) Then
            Console.WriteLine("7■    " & strLine)
            Return Status.iDeleteSelectContdition
        ElseIf rxRepository.IsMatch(strLine) Then
            Console.WriteLine("8■    " & strLine)
            Return Status.iRepository
        ElseIf rxProcess.IsMatch(strLine) Then
            Console.WriteLine("9■    " & strLine)
            Return Status.iProcess
        ElseIf rxViewInfo.IsMatch(strLine) Then
            Console.WriteLine("10■    " & strLine)
            Return Status.iViewInfo
        ElseIf rxLookupViewInfo.IsMatch(strLine) Then
            Console.WriteLine("12■    " & strLine)
            Return Status.iLookupViewInfo
        Else
            Return Status.iNone
        End If


        'If System.Text.RegularExpressions.Regex.IsMatch(strLine, regPatternColumn) Then
        'If System.Text.RegularExpressions.Regex.IsMatch(strLine, "^\\[Column\\]") Then
        'If System.Text.RegularExpressions.Regex.IsMatch(strLine, "^[Column]") Then
        'If System.Text.RegularExpressions.Regex.IsMatch(strLine, "\[Column\]") Then
        'Console.WriteLine("■" & strLine)
        'Return Status.iColumn
        'End If

        Return Status.iNone

    End Function
#End Region



End Class
